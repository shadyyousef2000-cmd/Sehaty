/* More: profile & goals, report, tools, settings, backup, boot */
(function () {
  'use strict';
  const A = window.App;
  const ACTLV = [[1.2, 'قليل الحركة (شغل مكتبي)', 'Sedentary (desk job)'], [1.375, 'نشاط خفيف (1–3 أيام/أسبوع)', 'Light (1–3 days/week)'], [1.55, 'نشاط متوسط (3–5 أيام)', 'Moderate (3–5 days)'], [1.725, 'نشاط عالي (6–7 أيام)', 'High (6–7 days)'], [1.9, 'شديد جدًا (عمل بدني + تمرين)', 'Very high (physical job + training)']];

  A.views.more = () => {
    if (A.ui.mtab === 'tools') return toolsView();
    if (A.ui.mtab === 'report') return reportView();
    if (A.ui.mtab === 'settings') return settingsView();
    const p = A.S.profile, g = A.S.goals;
    const row = (act, ic, ar, en, sub) => `<button class="lrow" data-act="${act}"><span class="li">${A.ic(ic)}</span><span class="in">${A.T(ar, en)}${sub ? `<small class="mut">${sub}</small>` : ''}</span>${A.ic(A.lang() === 'ar' ? 'left' : 'right', 'mut')}</button>`;
    return `<div class="top"><h1>${A.T('المزيد', 'More')}</h1></div>
      <div class="card"><div class="mh"><div><b>${A.T('هدفي اليومي', 'My daily target')}</b><small class="mut block">${p.sex === 'm' ? A.T('رجل', 'Male') : A.T('سيدة', 'Female')} · ${p.age} ${A.T('سنة', 'y')} · ${p.height} cm · ${A.fmt(A.lastWeight(), 1)} kg</small></div></div>
      <div class="stats3"><div><b>${A.fmt(g.kcal)}</b><small>${A.T('سعرة', 'kcal')}</small></div><div><b>${g.p}</b><small>${A.T('بروتين', 'protein')}</small></div><div><b>${A.n(g.c + '/' + g.f)}</b><small>${A.T('كارب/دهون', 'carb/fat')}</small></div></div>
      <button class="btn full" data-act="editProfile">${A.ic('user')} ${A.T('تعديل بياناتي وأهدافي', 'Edit profile & goals')}</button></div>
      <div class="list">${row('mTab', 'cal', 'التقرير الأسبوعي', 'Weekly report').replace('data-act="mTab"', 'data-act="mTab" data-t="report"')}
      ${row('mTab', 'dumb', 'الأدوات (1RM، صيام، BMI، نبض...)', 'Tools (1RM, fasting, BMI, heart rate...)').replace('data-act="mTab"', 'data-act="mTab" data-t="tools"')}
      ${row('mTab', 'grid', 'الإعدادات والنسخ الاحتياطي', 'Settings & backup').replace('data-act="mTab"', 'data-act="mTab" data-t="settings"')}</div>
      <p class="note">${A.T('كل المميزات مفتوحة، والتطبيق يعمل بدون إنترنت وبياناتك على جهازك فقط.', 'Every feature is unlocked, the app works offline, and your data stays on your device.')}</p><div class="pad"></div>`;
  };
  A.act.mTab = (el) => { A.ui.mtab = el.dataset.t; A.render(); };
  A.act.mBack = () => { A.ui.mtab = 'menu'; A.render(); };
  const back = (t) => `<div class="top"><button class="ib" data-act="mBack" aria-label="back">${A.lang() === 'ar' ? A.ic('right') : A.ic('left')}</button><h1>${t}</h1><span></span></div>`;

  /* ---------- profile ---------- */
  A.act.editProfile = () => {
    const p = A.S.profile, g = A.S.goals;
    A.modal(A.T('بياناتي وأهدافي', 'Profile & goals'), `<form data-frm="profile" class="form">
      <div class="seg"><label class="sg"><input type="radio" name="sex" value="m" ${p.sex === 'm' ? 'checked' : ''}><span>${A.T('رجل', 'Male')}</span></label><label class="sg"><input type="radio" name="sex" value="f" ${p.sex === 'f' ? 'checked' : ''}><span>${A.T('سيدة', 'Female')}</span></label></div>
      <div class="g2"><label>${A.T('السن', 'Age')}<input name="age" type="number" inputmode="numeric" value="${p.age}" required></label><label>${A.T('الطول (سم)', 'Height (cm)')}<input name="height" type="number" inputmode="decimal" value="${p.height}" required></label><label>${A.T('الوزن (كجم)', 'Weight (kg)')}<input name="weight" type="number" inputmode="decimal" step="0.1" value="${A.fmt(A.lastWeight(), 1)}" required></label><label>${A.T('وزن الهدف (كجم)', 'Goal weight (kg)')}<input name="gw" type="number" inputmode="decimal" step="0.1" value="${p.goalWeight}" required></label></div>
      <label>${A.T('مستوى النشاط', 'Activity level')}<select name="act">${ACTLV.map(([v, ar, en]) => `<option value="${v}" ${p.activity === v ? 'selected' : ''}>${A.T(ar, en)}</option>`).join('')}</select></label>
      <label>${A.T('الهدف', 'Goal')}<select name="goal"><option value="lose" ${p.goal === 'lose' ? 'selected' : ''}>${A.T('تخسيس', 'Lose weight')}</option><option value="maintain" ${p.goal === 'maintain' ? 'selected' : ''}>${A.T('تثبيت الوزن', 'Maintain')}</option><option value="gain" ${p.goal === 'gain' ? 'selected' : ''}>${A.T('زيادة وزن / عضل', 'Gain weight / muscle')}</option></select></label>
      <label>${A.T('السرعة (كجم/أسبوع)', 'Rate (kg/week)')}<select name="rate">${[0.25, 0.5, 0.75, 1].map((r) => `<option value="${r}" ${p.rate === r ? 'selected' : ''}>${r}</option>`).join('')}</select></label>
      <label class="chk"><input type="checkbox" name="auto" checked> ${A.T('احسب السعرات والماكروز تلقائيًا', 'Auto-calculate calories & macros')}</label>
      <details><summary>${A.T('تعديل الأهداف يدويًا', 'Edit targets manually')}</summary><div class="g2"><label>${A.T('سعرات', 'Calories')}<input name="kcal" type="number" value="${g.kcal}"></label><label>${A.T('بروتين (جم)', 'Protein (g)')}<input name="gp" type="number" value="${g.p}"></label><label>${A.T('كارب (جم)', 'Carbs (g)')}<input name="gc" type="number" value="${g.c}"></label><label>${A.T('دهون (جم)', 'Fat (g)')}<input name="gf" type="number" value="${g.f}"></label><label>${A.T('أكواب الماء', 'Water glasses')}<input name="water" type="number" value="${g.water}"></label><label>${A.T('دقائق نشاط/أسبوع', 'Active min/week')}<input name="amin" type="number" value="${g.activeMin}"></label></div></details>
      <button class="btn full" type="submit">${A.T('حفظ', 'Save')}</button></form>`);
  };
  A.frm.profile = (f, fd) => {
    const p = A.S.profile;
    Object.assign(p, { sex: fd.get('sex'), age: A.num(fd.get('age'), 25), height: A.num(fd.get('height'), 170), weight: A.num(fd.get('weight'), 70), goalWeight: A.num(fd.get('gw'), 70), activity: A.num(fd.get('act'), 1.375), goal: fd.get('goal'), rate: A.num(fd.get('rate'), 0.5) });
    const hw = A.S.health.weight, t = A.today(), last = hw[hw.length - 1];
    if (!last || last.v !== p.weight) { A.S.health.weight = hw.filter((x) => x.d !== t); A.S.health.weight.push({ id: A.uid(), d: t, v: p.weight }); }
    const g = A.S.goals;
    if (fd.get('auto') === 'on') { const a = A.autoGoals(p); Object.assign(g, a); }
    else Object.assign(g, { kcal: A.num(fd.get('kcal'), g.kcal), p: A.num(fd.get('gp'), g.p), c: A.num(fd.get('gc'), g.c), f: A.num(fd.get('gf'), g.f) });
    g.water = A.clamp(A.num(fd.get('water'), g.water), 1, 20); g.activeMin = A.num(fd.get('amin'), g.activeMin);
    A.S.onboarded = true; A.save(); A.closeModal(); A.toast(A.T('تم حفظ أهدافك', 'Goals saved'));
  };

  /* ---------- weekly report ---------- */
  function reportView() {
    const g = A.S.goals, days = []; for (let i = 6; i >= 0; i--) days.push(A.addDays(A.today(), -i));
    const logged = days.filter(A.hasFood), n = logged.length;
    const tot = logged.map((d) => A.totals(d));
    const avg = (key) => (n ? tot.reduce((s, t) => s + t[key], 0) / n : 0);
    const within = logged.filter((d) => { const k = A.totals(d).k; return k >= g.kcal * 0.9 && k <= g.kcal * 1.1; }).length;
    const burn = days.reduce((s, d) => s + A.burn(d), 0), sess = A.S.workouts.sessions.filter((s) => s.date >= days[0]).length;
    const wt = A.S.health.weight.filter((x) => x.d >= days[0]), wd = wt.length > 1 ? wt[wt.length - 1].v - wt[0].v : null;
    const wa = days.reduce((s, d) => s + (A.dayR(d).w || 0), 0) / 7;
    const bars = A.bars(days.map((d, i) => ({ l: A.pk(d).toLocaleDateString(A.loc(), { weekday: 'narrow' }), v: A.totals(d).k, cur: i === 6 })), { goal: g.kcal });
    const li = (ar, en, v) => `<div class="item static"><span class="in">${A.T(ar, en)}</span><span class="ik sm">${v}</span></div>`;
    return back(A.T('تقرير آخر 7 أيام', 'Last 7 days')) + `<div class="card"><b>${A.T('السعرات يوميًا', 'Calories per day')}</b>${bars}</div><div class="card">
      ${li('أيام التسجيل', 'Days logged', A.n(n + '/7'))}${li('متوسط السعرات', 'Avg calories', A.fmt(avg('k')))}${li('أيام قريبة من الهدف (±10%)', 'Days near goal (±10%)', A.n(within + '/' + n))}${li('متوسط البروتين', 'Avg protein', A.n(A.fmt(avg('p')) + ' / ' + g.p) + ' ' + A.T('جم', 'g'))}${li('متوسط الكارب / الدهون', 'Avg carbs / fat', A.n(A.fmt(avg('c')) + ' / ' + A.fmt(avg('f'))))}${li('إجمالي الحرق', 'Total burned', A.fmt(burn) + ' ' + A.T('سعرة', 'kcal'))}${li('تمارين الجيم', 'Gym sessions', sess)}${li('متوسط الماء', 'Avg water', A.fmt(wa, 1) + ' ' + A.T('كوب/يوم', 'glasses/day'))}${wd !== null ? li('تغيّر الوزن', 'Weight change', (wd > 0 ? '+' : '') + A.fmt(wd, 1) + ' kg') : ''}</div>
      <div class="card tip">${A.esc(reportTip(n, avg('k'), avg('p'), within, sess, g))}</div><div class="pad"></div>`;
  }
  function reportTip(n, k, p, within, sess, g) {
    if (n < 4) return A.T('سجّل أكتر من 4 أيام في الأسبوع عشان التقرير يبقى دقيق.', 'Log at least 4 days a week to make this report meaningful.');
    if (p < g.p * 0.8) return A.T('متوسط البروتين أقل من هدفك — زوّد البيض والفراخ والزبادي اليوناني والعدس.', 'Average protein is below your target — add more eggs, chicken, Greek yogurt and lentils.');
    if (k > g.kcal * 1.1) return A.T('متوسطك فوق الهدف. جرّب تقلل الزيوت والمشروبات المحلّاة والحلويات.', 'Your average is above target. Try cutting oils, sweet drinks and desserts.');
    if (sess < 2) return A.T('جرّب تحط 2–3 تمارين مقاومة في الأسبوع للحفاظ على العضلات.', 'Aim for 2–3 resistance sessions a week to protect muscle.');
    return A.T('أسبوع ممتاز — كمّل على نفس النظام! 👏', 'Great week — keep it up! 👏');
  }

  /* ---------- tools ---------- */
  function toolsView() {
    const p = A.S.profile, w = A.lastWeight(), bmi = A.bmi(w, p.height), lo = 18.5 * Math.pow(p.height / 100, 2), hi = 24.9 * Math.pow(p.height / 100, 2);
    const devine = (p.sex === 'm' ? 50 : 45.5) + 2.3 * (p.height / 2.54 - 60);
    const mhr = Math.round(208 - 0.7 * p.age);
    const zones = [[0.5, 0.6, 'إحماء / تعافي', 'Warm-up / recovery'], [0.6, 0.7, 'حرق دهون', 'Fat burn'], [0.7, 0.8, 'لياقة قلبية', 'Aerobic'], [0.8, 0.9, 'أداء عالي', 'Hard'], [0.9, 1, 'أقصى مجهود', 'Max']];
    const f = A.S.fasting, on = !!f.start;
    const prog = on ? A.clamp((Date.now() - f.start) / (f.hours * 3600000), 0, 1) : 0;
    return back(A.T('الأدوات', 'Tools')) + `
      <div class="card"><h3>${A.T('الصيام المتقطع', 'Intermittent fasting')}</h3>
        <div class="ringbox sm">${A.ring(prog, 1, { size: 130, color: 'var(--acc3)' })}<div class="rc"><b id="fastClock">${A.fastElapsed()}</b><small>${A.T('من', 'of')} ${f.hours}h</small></div></div>
        <div class="chips c">${[12, 14, 16, 18, 20].map((h) => `<button class="chip ${f.hours === h ? 'on' : ''}" data-act="fastH" data-h="${h}">${h}h</button>`).join('')}</div>
        <button class="btn full ${on ? 'danger' : ''}" data-act="fastToggle">${on ? A.T('إنهاء الصيام', 'End fast') : A.T('ابدأ الصيام الآن', 'Start fast now')}</button>
        ${f.history.slice(-3).reverse().map((x) => `<div class="item static"><span class="in">${A.esc(A.dshort(A.dkey(new Date(x.start))))}</span><span class="ik sm">${A.fmt((x.end - x.start) / 3600000, 1)}h</span></div>`).join('')}</div>
      <div class="card"><h3>${A.T('حاسبة 1RM (أقصى وزن)', '1RM calculator')}</h3><div class="g2"><label>${A.T('الوزن (كجم)', 'Weight (kg)')}<input type="number" inputmode="decimal" id="rmW" data-inp="rm"></label><label>${A.T('العدّات', 'Reps')}<input type="number" inputmode="numeric" id="rmR" data-inp="rm"></label></div><div id="rmOut" class="note">${A.T('اكتب الوزن والعدّات', 'Enter weight and reps')}</div></div>
      <div class="card"><h3>${A.T('حاسبة الأطواق (Plates)', 'Plate calculator')}</h3><div class="g2"><label>${A.T('الوزن المطلوب (كجم)', 'Target (kg)')}<input type="number" inputmode="decimal" id="plT" data-inp="plate"></label><label>${A.T('وزن البار', 'Bar (kg)')}<input type="number" inputmode="decimal" id="plB" value="20" data-inp="plate"></label></div><div id="plOut" class="note"></div></div>
      <div class="card"><h3>BMI · ${A.T('الوزن المثالي', 'Healthy weight')}</h3><p><b>${A.fmt(bmi, 1)}</b> · ${A.bmiClass(bmi)[0]}</p><p class="mut">${A.T('المدى الصحي لطولك', 'Healthy range for your height')}: <b>${A.n(A.fmt(lo, 1) + ' – ' + A.fmt(hi, 1))}</b> kg · ${A.T('معادلة ديفاين', 'Devine')}: <b>${A.fmt(devine, 1)}</b> kg</p><p class="mut">BMR: <b>${A.fmt(A.bmr())}</b> · TDEE: <b>${A.fmt(A.tdee())}</b> ${A.T('سعرة', 'kcal')} · ${A.T('ماء يوميًا', 'Water/day')}: <b>${A.fmt(w * 0.035, 1)}</b> L</p></div>
      <div class="card"><h3>${A.T('مناطق النبض', 'Heart-rate zones')}</h3><p class="mut">${A.T('أقصى نبض تقديري', 'Estimated max HR')}: <b>${mhr}</b> bpm</p>${zones.map(([a, b, ar, en]) => `<div class="item static"><span class="in">${A.T(ar, en)}</span><span class="ik sm">${A.n(Math.round(mhr * a) + '–' + Math.round(mhr * b))}</span></div>`).join('')}</div><div class="pad"></div>`;
  }
  A.inp.rm = () => {
    const w = A.num(document.getElementById('rmW').value), r = A.num(document.getElementById('rmR').value), o = document.getElementById('rmOut');
    if (!w || !r) { o.textContent = A.T('اكتب الوزن والعدّات', 'Enter weight and reps'); return; }
    const ep = w * (1 + r / 30), br = r < 37 ? w * 36 / (37 - r) : ep, rm = (ep + br) / 2;
    o.innerHTML = `<b>${A.fmt(rm, 1)} kg</b> (1RM)<div class="chips">${[95, 90, 85, 80, 75, 70, 60, 50].map((x) => `<span class="chip">${x}% · ${A.fmt(rm * x / 100, 1)}</span>`).join('')}</div>`;
  };
  A.inp.plate = () => {
    const t = A.num(document.getElementById('plT').value), b = A.num(document.getElementById('plB').value, 20), o = document.getElementById('plOut');
    if (!t || t < b) { o.textContent = ''; return; }
    let per = (t - b) / 2; const out = [];
    for (const pl of [25, 20, 15, 10, 5, 2.5, 1.25]) { const n = Math.floor(per / pl + 1e-9); if (n) { out.push(n + '×' + pl); per -= n * pl; } }
    o.innerHTML = `${A.T('على كل جانب', 'Each side')}: <b>${out.join(' + ') || '—'}</b>${per > 0.01 ? ` <span class="mut">(${A.T('متبقي', 'left')} ${A.fmt(per * 2, 2)} kg)</span>` : ''}`;
  };
  A.act.fastH = (el) => { A.S.fasting.hours = +el.dataset.h; A.save(); A.render(); };
  A.act.fastToggle = () => {
    const f = A.S.fasting;
    if (f.start) { f.history.push({ start: f.start, end: Date.now() }); f.history = f.history.slice(-30); f.start = null; } else f.start = Date.now();
    A.save(); A.render();
  };

  /* ---------- settings & backup ---------- */
  function settingsView() {
    const s = A.S.settings, seg = (name, val, opts) => `<div class="seg">${opts.map(([v, l]) => `<button class="${val === v ? 'on' : ''}" data-act="setOpt" data-n="${name}" data-v="${v}">${l}</button>`).join('')}</div>`;
    return back(A.T('الإعدادات', 'Settings')) + `<div class="card"><label class="lbl">${A.T('اللغة', 'Language')}</label>${seg('lang', s.lang, [['ar', 'العربية'], ['en', 'English']])}
      <label class="lbl">${A.T('المظهر', 'Theme')}</label>${seg('theme', s.theme, [['auto', A.T('تلقائي', 'Auto')], ['light', A.T('فاتح', 'Light')], ['dark', A.T('داكن', 'Dark')]])}
      <label class="lbl">${A.T('مؤقت الراحة بين المجموعات', 'Rest timer between sets')}</label>${seg('rest', s.rest, [[0, A.T('إيقاف', 'Off')], [60, '60s'], [90, '90s'], [120, '120s'], [180, '180s']])}
      <label class="lbl">${A.T('إضافة سعرات الحرق لميزانية اليوم', 'Add exercise calories to daily budget')}</label>${seg('addEx', s.addEx, [[true, A.T('نعم', 'Yes')], [false, A.T('لا', 'No')]])}
      <label class="lbl">${A.T('الصوت والاهتزاز', 'Sound & vibration')}</label>${seg('sound', s.sound, [[true, A.T('تشغيل', 'On')], [false, A.T('إيقاف', 'Off')]])}</div>
      <div class="card"><h3>${A.T('نسخ احتياطي', 'Backup')}</h3><p class="note">${A.T('بياناتك على الجهاز فقط. خد نسخة احتياطية كل فترة، خصوصًا قبل تغيير الموبايل.', 'Your data lives on this device only. Back up regularly, especially before changing phones.')}</p>
      <div class="row gap"><button class="btn grow" data-act="exportJson">${A.T('تصدير JSON', 'Export JSON')}</button><button class="btn ghost grow" data-act="exportCsv">${A.T('أكل CSV', 'Food CSV')}</button></div>
      <button class="btn ghost full" data-act="copyJson">${A.T('نسخ البيانات للحافظة', 'Copy data to clipboard')}</button>
      <label class="btn ghost full filebtn">${A.T('استيراد ملف نسخة احتياطية', 'Import backup file')}<input type="file" accept=".json,application/json" data-chg="importFile" hidden></label>
      <button class="btn ghost full" data-act="importPaste">${A.T('استيراد بلصق النص', 'Import by pasting text')}</button>
      <button class="btn danger full" data-act="resetAll">${A.ic('trash')} ${A.T('مسح كل البيانات', 'Erase all data')}</button></div>
      <p class="note">${A.T('الإصدار', 'Version')} 1.0 · ${A.T('القيم الغذائية تقريبية وللإرشاد فقط.', 'Nutrition values are approximate and for guidance only.')}</p><div class="pad"></div>`;
  }
  A.act.setOpt = (el) => {
    const n = el.dataset.n; let v = el.dataset.v;
    if (v === 'true') v = true; else if (v === 'false') v = false; else if (n === 'rest') v = +v;
    A.S.settings[n] = v; A.save(); A.render();
  };
  const stamp = () => A.today();
  function deliver(name, text, mime) {
    const P = window.Capacitor && window.Capacitor.Plugins;
    if (P && P.Filesystem && P.Share) {
      P.Filesystem.writeFile({ path: name, data: text, directory: 'CACHE', encoding: 'utf8' })
        .then((r) => P.Share.share({ title: name, url: r.uri })).catch(() => A.copyText(text));
      return;
    }
    try {
      const url = URL.createObjectURL(new Blob([text], { type: mime }));
      const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      A.toast(A.T('تم التصدير', 'Exported'));
    } catch (e) { A.copyText(text); }
  }
  A.act.exportJson = () => deliver('sehaty-backup-' + stamp() + '.json', JSON.stringify(A.S), 'application/json');
  A.act.copyJson = () => A.copyText(JSON.stringify(A.S));
  A.act.exportCsv = () => {
    const rows = [['date', 'meal', 'name', 'servings', 'unit', 'kcal', 'protein', 'carbs', 'fat']];
    Object.keys(A.S.diary).sort().forEach((d) => ['b', 'l', 'd', 's'].forEach((m) => (A.S.diary[d].m[m] || []).forEach((i) => rows.push([d, m, i.ar, i.q, i.uAr, A.r(i.k * i.q), A.r(i.p * i.q, 1), A.r(i.c * i.q, 1), A.r(i.f * i.q, 1)]))));
    const csv = '﻿' + rows.map((r) => r.map((c) => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\n');
    deliver('sehaty-food-' + stamp() + '.csv', csv, 'text/csv');
  };
  function doImport(txt) {
    try {
      const o = JSON.parse(txt); if (!o || typeof o !== 'object' || !o.settings || !o.diary) throw new Error('bad');
      A.confirm(A.T('هيتم استبدال بياناتك الحالية بالنسخة دي. متأكد؟', 'This will replace your current data. Continue?'), () => { A.S = A.merge(A.defaults(), o); A.saveNow(); A.closeModal(); A.ui.mtab = 'menu'; A.render(); A.toast(A.T('تم الاستيراد', 'Imported')); });
    } catch (e) { A.toast(A.T('الملف غير صالح', 'Invalid backup')); }
  }
  A.chg.importFile = (el) => { const f = el.files && el.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => doImport(String(r.result)); r.readAsText(f); el.value = ''; };
  A.act.importPaste = () => A.modal(A.T('استيراد', 'Import'), `<form data-frm="pasteImport" class="form"><textarea name="t" rows="8" placeholder="{ ... }" required></textarea><button class="btn full" type="submit">${A.T('استيراد', 'Import')}</button></form>`);
  A.frm.pasteImport = (f, fd) => doImport(String(fd.get('t')));
  A.act.resetAll = () => A.confirm(A.T('مسح كل البيانات نهائيًا؟ لا يمكن التراجع.', 'Erase ALL data permanently? This cannot be undone.'), () => A.confirm(A.T('تأكيد أخير: مسح كل شيء؟', 'Final check: erase everything?'), () => { const lang = A.S.settings.lang; A.S = A.defaults(); A.S.settings.lang = lang; A.saveNow(); A.ui.mtab = 'menu'; A.render(); A.act.editProfile(); }));

  /* ---------- boot ---------- */
  function boot() {
    A.render();
    if (!A.S.onboarded) A.act.editProfile();
    A.scheduleMeds();
    const sp = document.getElementById('splash'); if (sp) setTimeout(() => sp.remove(), 150);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
