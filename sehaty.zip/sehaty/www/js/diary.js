/* Today (food diary), water, add food */
(function () {
  'use strict';
  const A = window.App, D = window.DATA;
  const mealName = (id) => { const m = A.MEALS.find((x) => x[0] === id); return A.T(m[1], m[2]); };

  A.views.today = () => {
    const k = A.ui.date, g = A.S.goals, t = A.totals(k), burn = A.burn(k), addEx = A.S.settings.addEx;
    const budget = g.kcal + (addEx ? burn : 0), rem = budget - t.k, over = rem < 0;
    const st = A.streak(), d = A.dayR(k);
    const fast = A.S.fasting.start ? `<button class="chip warnc" data-act="goTools">${A.ic('clock')} ${A.T('صيام جارٍ', 'Fasting')} · ${A.fastElapsed()}</button>` : '';
    const macro = (lab, v, goal, cls) => `<div class="mrow"><div class="ml"><span>${lab}</span><span class="mut">${A.n(A.fmt(v) + ' / ' + A.fmt(goal))} ${A.T('جم', 'g')}</span></div><div class="bar"><i class="${cls}" style="width:${A.clamp(goal ? v / goal * 100 : 0, 0, 100)}%"></i></div></div>`;
    let h = `<div class="top"><h1>${A.T('يومياتي', 'My Diary')}</h1><div class="row gap">${fast}${st ? `<span class="chip">${A.ic('flame')} ${st} ${A.T('يوم متواصل', 'day streak')}</span>` : ''}</div></div>${A.dateNav()}`;
    h += `<div class="card hero"><div class="ringbox">${A.ring(t.k, budget, { size: 148, color: over ? 'var(--bad)' : 'var(--acc)' })}<div class="rc"><b class="${over ? 'bad' : ''}">${A.fmt(Math.abs(rem))}</b><small>${over ? A.T('زيادة', 'over') : A.T('متبقي', 'left')}</small></div></div>
      <div class="eq"><div><b>${A.fmt(g.kcal)}</b><small>${A.T('الهدف', 'Goal')}</small></div><div><b>${A.fmt(t.k)}</b><small>${A.T('أكل', 'Food')}</small></div><div><b>${A.fmt(burn)}</b><small>${A.T('حرق', 'Burned')}</small></div></div></div>`;
    h += `<div class="card">${macro(A.T('بروتين', 'Protein'), t.p, g.p, 'bp')}${macro(A.T('كربوهيدرات', 'Carbs'), t.c, g.c, 'bc')}${macro(A.T('دهون', 'Fat'), t.f, g.f, 'bf')}</div>`;
    for (const [id] of A.MEALS) {
      const items = d.m[id] || [], mt = A.mealTotals(items);
      h += `<div class="card meal"><div class="mh"><div><b>${mealName(id)}</b><small class="mut"> · ${A.fmt(mt.k)} ${A.T('سعرة', 'kcal')}</small></div><div class="row"><button class="ib" data-act="mealMenu" data-m="${id}" aria-label="menu">${A.ic('more')}</button><button class="ib acc" data-act="addFood" data-m="${id}" aria-label="add">${A.ic('plus')}</button></div></div>`;
      if (!items.length) h += `<button class="addline" data-act="addFood" data-m="${id}">${A.T('+ أضف أكل', '+ Add food')}</button>`;
      for (const it of items) {
        h += `<button class="item" data-act="editItem" data-m="${id}" data-i="${it.id}"><span class="in">${A.esc(A.nm(it))}<small class="mut">${A.fmt(it.q, 2)} × ${A.esc(A.un(it))}</small></span><span class="ik">${A.fmt(it.k * it.q)}</span></button>`;
      }
      h += `</div>`;
    }
    // water
    const gl = g.water, w = d.w || 0;
    let glasses = '';
    for (let i = 0; i < gl; i++) glasses += `<button class="gl ${i < w ? 'full' : ''}" data-act="setWater" data-n="${i + 1}" aria-label="glass ${i + 1}">${A.ic('drop')}</button>`;
    h += `<div class="card"><div class="mh"><div><b>${A.T('الماء', 'Water')}</b><small class="mut"> · ${A.n(w * 250 + ' / ' + gl * 250)} ${A.T('مل', 'ml')}</small></div><div class="row"><button class="ib" data-act="waterDec">${A.ic('minus')}</button><button class="ib acc" data-act="waterInc">${A.ic('plus')}</button></div></div><div class="glasses">${glasses}</div></div>`;
    // activity summary
    h += `<div class="card link" data-act="tab" data-t="activity"><div class="mh"><div><b>${A.T('النشاط والتمارين', 'Exercise')}</b><small class="mut"> · ${A.activeMin(k)} ${A.T('دقيقة', 'min')}</small></div><b class="accc">${A.fmt(burn)} ${A.T('سعرة', 'kcal')}</b></div></div>`;
    const tip = tipFor(k, t, g);
    if (tip) h += `<div class="card tip">${A.esc(tip)}</div>`;
    return h + '<div class="pad"></div>';
  };

  function tipFor(k, t, g) {
    if (!A.hasFood(k)) return k === A.today() ? A.T('ابدأ بتسجيل أول وجبة — التسجيل المنتظم هو سر النتيجة.', 'Log your first meal — consistent logging is what drives results.') : '';
    const hr = new Date().getHours();
    if (k === A.today() && hr >= 16 && t.p < g.p * 0.5) return A.T('البروتين لسه أقل من نص هدفك. جرّب بيض، زبادي يوناني، فراخ، تونة أو عدس.', 'Protein is under half your goal. Try eggs, Greek yogurt, chicken, tuna or lentils.');
    if (t.k > g.kcal * 1.15) return A.T('عديت هدف السعرات. مفيش مشكلة — حاول تعوّض بمشي خفيف وخلي وجبتك الجاية خفيفة.', 'You\'re over your calorie goal. No big deal — a light walk and a lighter next meal will balance it.');
    if ((A.dayR(k).w || 0) < 3 && hr >= 15 && k === A.today()) return A.T('الماء قليل النهارده — اشرب كوب دلوقتي.', 'Water is low today — have a glass now.');
    return '';
  }

  /* ---------- water ---------- */
  A.act.setWater = (el) => { const d = A.dayW(A.ui.date), n = parseInt(el.dataset.n, 10); d.w = d.w === n ? n - 1 : n; A.save(); A.render(); };
  A.act.waterInc = () => { const d = A.dayW(A.ui.date); d.w = (d.w || 0) + 1; A.save(); A.render(); };
  A.act.waterDec = () => { const d = A.dayW(A.ui.date); d.w = Math.max(0, (d.w || 0) - 1); A.save(); A.render(); };

  /* ---------- add food ---------- */
  let add = { meal: 'b', tab: 'search', q: '', cat: 'all', sel: null };
  A.act.addFood = (el) => { add = { meal: el.dataset.m, tab: 'search', q: '', cat: 'all', sel: null }; renderAdd(true); };
  A.act.goTools = () => { A.ui.tab = 'more'; A.ui.mtab = 'tools'; A.render(); };

  function renderAdd(open) {
    const tabs = [['search', A.T('بحث', 'Search')], ['fav', A.T('مفضلة', 'Favorites')], ['custom', A.T('أكلي', 'My foods')], ['quick', A.T('سريع', 'Quick')]];
    let body = `<div class="seg">${tabs.map(([id, l]) => `<button class="${add.tab === id ? 'on' : ''}" data-act="addTab" data-t="${id}">${l}</button>`).join('')}</div>`;
    if (add.tab === 'search') {
      body += `<div class="searchbox">${A.ic('search')}<input type="search" id="addq" placeholder="${A.T('ابحث: كشري، فراخ، موز...', 'Search: koshary, chicken, banana...')}" value="${A.esc(add.q)}" data-inp="addq" autocomplete="off"></div>
        <div class="chips"><button class="chip ${add.cat === 'all' ? 'on' : ''}" data-act="addCat" data-c="all">${A.T('الكل', 'All')}</button>${D.cats.map((c) => `<button class="chip ${add.cat === c.id ? 'on' : ''}" data-act="addCat" data-c="${c.id}">${A.esc(A.nm(c))}</button>`).join('')}</div><div id="addRes">${resultsHTML()}</div>`;
    } else if (add.tab === 'fav') {
      const favs = A.S.foods.fav.map(A.foodById).filter(Boolean);
      const rec = A.S.foods.recent.map(A.foodById).filter(Boolean);
      body += `<h3>${A.T('المفضلة', 'Favorites')}</h3>${listFoods(favs, A.T('اضغط ★ على أي أكلة لإضافتها هنا', 'Tap ★ on any food to add it here'))}<h3>${A.T('الأخيرة', 'Recent')}</h3>${listFoods(rec, A.T('لا يوجد بعد', 'Nothing yet'))}`;
    } else if (add.tab === 'custom') {
      const cu = A.S.foods.custom;
      body += `<button class="btn full" data-act="newCustom">${A.ic('plus')} ${A.T('أكلة جديدة', 'New food')}</button>${listFoods(cu, A.T('لسه ما أضفتش أكلات خاصة', 'No custom foods yet'))}`;
    } else {
      body += `<form data-frm="quickAdd" class="form"><label>${A.T('الاسم (اختياري)', 'Name (optional)')}<input name="n" placeholder="${A.T('سعرات سريعة', 'Quick calories')}"></label>
        <div class="g2"><label>${A.T('سعرات', 'Calories')}<input name="k" type="number" inputmode="decimal" required></label><label>${A.T('بروتين (جم)', 'Protein (g)')}<input name="p" type="number" inputmode="decimal"></label><label>${A.T('كربوهيدرات (جم)', 'Carbs (g)')}<input name="c" type="number" inputmode="decimal"></label><label>${A.T('دهون (جم)', 'Fat (g)')}<input name="f" type="number" inputmode="decimal"></label></div>
        <button class="btn full" type="submit">${A.T('إضافة', 'Add')}</button></form>`;
    }
    const title = A.T('إضافة إلى ', 'Add to ') + mealName(add.meal);
    if (open) A.modal(title, body); else A.setModalBody(body);
  }

  function listFoods(arr, empty) {
    if (!arr.length) return `<div class="empty">${empty}</div>`;
    return arr.map(foodRow).join('');
  }
  function foodRow(f) {
    const fav = A.S.foods.fav.includes(f.id);
    return `<div class="frow"><button class="fmain" data-act="pickFood" data-id="${f.id}"><span class="in">${A.esc(A.nm(f))}<small class="mut">${A.esc(A.un(f))} · P${A.fmt(f.p)} C${A.fmt(f.c)} F${A.fmt(f.f)}</small></span><span class="ik">${A.fmt(f.k)}</span></button><button class="ib ${fav ? 'starred' : ''}" data-act="toggleFav" data-id="${f.id}" aria-label="favorite">${A.ic('star')}</button></div>`;
  }
  function resultsHTML() {
    const q = A.norm(add.q);
    let list = A.allFoods();
    if (add.cat !== 'all') list = list.filter((f) => f.cat === add.cat);
    if (q) {
      const toks = q.split(/\s+/).filter(Boolean);
      const sc = [];
      for (const f of list) {
        const n = A.norm(f.ar + ' ' + f.en);
        if (toks.every((t) => n.includes(t))) sc.push([n.startsWith(toks[0]) ? 0 : n.includes(' ' + toks[0]) ? 1 : 2, f]);
      }
      sc.sort((a, b) => a[0] - b[0]);
      list = sc.map((x) => x[1]);
    }
    if (!list.length) return `<div class="empty">${A.T('مفيش نتائج — جرّب كلمة تانية أو أضف الأكلة من تبويب "أكلي"', 'No results — try another word or add it in "My foods"')}</div>`;
    return list.slice(0, 80).map(foodRow).join('');
  }
  A.inp.addq = (el) => { add.q = el.value; const r = document.getElementById('addRes'); if (r) r.innerHTML = resultsHTML(); };
  A.act.addTab = (el) => { add.tab = el.dataset.t; add.sel = null; renderAdd(false); };
  A.act.addCat = (el) => { add.cat = el.dataset.c; renderAdd(false); const q = document.getElementById('addq'); if (q) q.focus(); };
  A.act.toggleFav = (el) => {
    const id = el.dataset.id, fav = A.S.foods.fav, i = fav.indexOf(id);
    if (i >= 0) fav.splice(i, 1); else fav.unshift(id);
    A.save(); renderAdd(false);
  };
  A.act.newCustom = () => {
    A.setModalBody(`<form data-frm="customFood" class="form"><label>${A.T('اسم الأكلة', 'Food name')}<input name="n" required></label><label>${A.T('وحدة الحصة (مثال: طبق، 100 جم)', 'Serving label (e.g. plate, 100 g)')}<input name="u" value="${A.T('حصة', 'serving')}" required></label>
      <div class="g2"><label>${A.T('سعرات', 'Calories')}<input name="k" type="number" inputmode="decimal" required></label><label>${A.T('بروتين (جم)', 'Protein (g)')}<input name="p" type="number" inputmode="decimal"></label><label>${A.T('كربوهيدرات (جم)', 'Carbs (g)')}<input name="c" type="number" inputmode="decimal"></label><label>${A.T('دهون (جم)', 'Fat (g)')}<input name="f" type="number" inputmode="decimal"></label></div>
      <div class="row gap"><button class="btn ghost grow" type="button" data-act="addTab" data-t="custom">${A.T('رجوع', 'Back')}</button><button class="btn grow" type="submit">${A.T('حفظ', 'Save')}</button></div></form>`);
  };
  A.frm.customFood = (f, fd) => {
    const n = String(fd.get('n')).trim(), u = String(fd.get('u')).trim();
    A.S.foods.custom.unshift({ id: 'c' + A.uid(), cat: 'custom', ar: n, en: n, uAr: u, uEn: u, k: A.num(fd.get('k')), p: A.num(fd.get('p')), c: A.num(fd.get('c')), f: A.num(fd.get('f')) });
    A.save(); A.toast(A.T('تم الحفظ', 'Saved')); add.tab = 'custom'; renderAdd(false);
  };
  A.frm.quickAdd = (f, fd) => {
    const n = String(fd.get('n') || '').trim() || A.T('سعرات سريعة', 'Quick calories');
    pushItem(add.meal, { ar: n, en: n, uAr: 'حصة', uEn: 'serving', k: A.num(fd.get('k')), p: A.num(fd.get('p')), c: A.num(fd.get('c')), f: A.num(fd.get('f')) }, 1);
    A.toast(A.T('تمت الإضافة', 'Added')); f.reset();
  };
  function pushItem(meal, food, q) {
    const d = A.dayW(A.ui.date);
    d.m[meal].push({ id: A.uid(), ar: food.ar, en: food.en, uAr: food.uAr, uEn: food.uEn, k: food.k, p: food.p, c: food.c, f: food.f, q });
    if (food.id) { const r = A.S.foods.recent; const i = r.indexOf(food.id); if (i >= 0) r.splice(i, 1); r.unshift(food.id); r.length = Math.min(r.length, 20); }
    A.save();
  }
  A.act.pickFood = (el) => {
    const f = A.foodById(el.dataset.id); if (!f) return;
    add.sel = f;
    A.setModalBody(qtyHTML(f, 1));
  };
  function qtyHTML(f, q) {
    const opts = A.MEALS.map(([id]) => `<option value="${id}" ${id === add.meal ? 'selected' : ''}>${mealName(id)}</option>`).join('');
    return `<div class="qty"><h3>${A.esc(A.nm(f))}</h3><p class="mut">${A.T('الحصة:', 'Serving:')} ${A.esc(A.un(f))}</p>
      <div class="stepper"><button class="ib" data-act="qtyStep" data-n="-0.5">${A.ic('minus')}</button><input id="qtyIn" type="number" inputmode="decimal" step="0.25" min="0" value="${q}" data-inp="qty"><button class="ib" data-act="qtyStep" data-n="0.5">${A.ic('plus')}</button></div>
      <div id="qprev" class="prev">${prevHTML(f, q)}</div>
      <label class="lbl">${A.T('الوجبة', 'Meal')}<select id="qMeal" data-chg="qMeal">${opts}</select></label>
      <div class="row gap"><button class="btn ghost grow" data-act="addTab" data-t="${add.tab}">${A.T('رجوع', 'Back')}</button><button class="btn grow" data-act="confirmAdd">${A.T('إضافة', 'Add')}</button></div></div>`;
  }
  function prevHTML(f, q) {
    return `<div><b>${A.fmt(f.k * q)}</b><small>${A.T('سعرة', 'kcal')}</small></div><div><b>${A.fmt(f.p * q, 1)}</b><small>${A.T('بروتين', 'P')}</small></div><div><b>${A.fmt(f.c * q, 1)}</b><small>${A.T('كارب', 'C')}</small></div><div><b>${A.fmt(f.f * q, 1)}</b><small>${A.T('دهون', 'F')}</small></div>`;
  }
  A.inp.qty = (el) => { const p = document.getElementById('qprev'); if (p && add.sel) p.innerHTML = prevHTML(add.sel, A.num(el.value)); };
  A.chg.qMeal = (el) => { add.meal = el.value; };
  A.act.qtyStep = (el) => {
    const i = document.getElementById('qtyIn'); const v = Math.max(0, A.r(A.num(i.value) + parseFloat(el.dataset.n), 2));
    i.value = v; A.inp.qty(i);
  };
  A.act.confirmAdd = () => {
    const q = A.num(document.getElementById('qtyIn').value);
    if (!(q > 0) || !add.sel) { A.toast(A.T('اكتب كمية صحيحة', 'Enter a valid amount')); return; }
    pushItem(add.meal, add.sel, q);
    A.toast(A.T('تمت الإضافة ✓', 'Added ✓')); add.sel = null; add.tab = 'search'; renderAdd(false); A.render();
  };

  /* ---------- edit item / meal menu ---------- */
  A.act.editItem = (el) => {
    const m = el.dataset.m, d = A.dayR(A.ui.date), it = d.m[m].find((x) => x.id === el.dataset.i); if (!it) return;
    const opts = A.MEALS.map(([id]) => `<option value="${id}" ${id === m ? 'selected' : ''}>${mealName(id)}</option>`).join('');
    A.modal(A.nm(it), `<form data-frm="editItem" data-m="${m}" data-i="${it.id}" class="form"><p class="mut">${A.T('الحصة:', 'Serving:')} ${A.esc(A.un(it))} · ${A.fmt(it.k)} ${A.T('سعرة', 'kcal')}</p>
      <label>${A.T('الكمية (عدد الحصص)', 'Amount (servings)')}<input name="q" type="number" step="0.25" min="0" inputmode="decimal" value="${it.q}" required></label>
      <label>${A.T('الوجبة', 'Meal')}<select name="m">${opts}</select></label>
      <div class="row gap"><button class="btn danger grow" type="button" data-act="delItem" data-m="${m}" data-i="${it.id}">${A.ic('trash')} ${A.T('حذف', 'Delete')}</button><button class="btn grow" type="submit">${A.T('حفظ', 'Save')}</button></div></form>`);
  };
  A.frm.editItem = (f, fd) => {
    const m = f.dataset.m, d = A.dayW(A.ui.date), idx = d.m[m].findIndex((x) => x.id === f.dataset.i); if (idx < 0) return;
    const it = d.m[m][idx]; it.q = A.num(fd.get('q'), 1);
    const nm = fd.get('m'); if (nm !== m) { d.m[m].splice(idx, 1); d.m[nm].push(it); }
    A.save(); A.closeModal();
  };
  A.act.delItem = (el) => { const d = A.dayW(A.ui.date), m = el.dataset.m; d.m[m] = d.m[m].filter((x) => x.id !== el.dataset.i); A.save(); A.closeModal(); };
  A.act.mealMenu = (el) => {
    const m = el.dataset.m;
    A.modal(mealName(m), `<div class="list"><button class="lrow" data-act="copyPrev" data-m="${m}">${A.T('نسخ نفس الوجبة من أمس', 'Copy this meal from yesterday')}</button><button class="lrow" data-act="saveCombo" data-m="${m}">${A.T('حفظ الوجبة كأكلة جاهزة (كومبو)', 'Save meal as a combo food')}</button><button class="lrow bad" data-act="clearMeal" data-m="${m}">${A.T('مسح الوجبة', 'Clear meal')}</button></div>`);
  };
  A.act.copyPrev = (el) => {
    const m = el.dataset.m, prev = A.dayR(A.addDays(A.ui.date, -1)).m[m] || [];
    if (!prev.length) { A.toast(A.T('مفيش وجبة أمس', 'Nothing to copy')); return; }
    const d = A.dayW(A.ui.date); prev.forEach((x) => d.m[m].push(Object.assign({}, x, { id: A.uid() })));
    A.save(); A.closeModal(); A.toast(A.T('تم النسخ', 'Copied'));
  };
  A.act.clearMeal = (el) => { A.confirm(A.T('مسح كل أكل الوجبة دي؟', 'Clear all items in this meal?'), () => { A.dayW(A.ui.date).m[el.dataset.m] = []; A.save(); A.closeModal(); }); };
  A.act.saveCombo = (el) => {
    const m = el.dataset.m, items = A.dayR(A.ui.date).m[m] || [];
    if (!items.length) { A.toast(A.T('الوجبة فاضية', 'Meal is empty')); return; }
    A.setModalBody(`<form data-frm="combo" data-m="${m}" class="form"><label>${A.T('اسم الكومبو', 'Combo name')}<input name="n" required></label><button class="btn full" type="submit">${A.T('حفظ', 'Save')}</button></form>`);
  };
  A.frm.combo = (f, fd) => {
    const t = A.mealTotals(A.dayR(A.ui.date).m[f.dataset.m] || []), n = String(fd.get('n')).trim();
    A.S.foods.custom.unshift({ id: 'c' + A.uid(), cat: 'custom', ar: n, en: n, uAr: 'وجبة', uEn: 'meal', k: A.r(t.k), p: A.r(t.p, 1), c: A.r(t.c, 1), f: A.r(t.f, 1) });
    A.save(); A.closeModal(); A.toast(A.T('تم الحفظ في "أكلي"', 'Saved to "My foods"'));
  };

  /* ---------- fasting helper ---------- */
  A.fastElapsed = () => {
    const s = A.S.fasting.start; if (!s) return '0:00';
    const m = Math.floor((Date.now() - s) / 60000); return Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0');
  };
})();
