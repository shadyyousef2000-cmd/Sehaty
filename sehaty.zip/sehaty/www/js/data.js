/* Built-in data: Egyptian-focused foods (approximate values per serving), exercises, templates */
(function () {
  const foods = [];
  const f = (cat, ar, en, uAr, uEn, k, p, c, fa) =>
    foods.push({ id: 'f' + foods.length, cat, ar, en, uAr, uEn, k, p, c, f: fa });

  // ---- أطباق مصرية ----
  f('egy','كشري','Koshary','طبق متوسط','medium plate',550,15,98,10);
  f('egy','فول مدمس بالزيت','Ful medames with oil','طبق (150 جم)','plate (150 g)',210,12,26,7);
  f('egy','طعمية / فلافل','Ta\'ameya / Falafel','قرص','piece',95,4,8,5.5);
  f('egy','ملوخية بالفراخ','Molokhia with chicken','طبق','plate',280,22,12,16);
  f('egy','ملوخية (بدون لحم)','Molokhia (plain)','طبق','plate',150,6,12,8);
  f('egy','بامية باللحم','Okra stew with meat','طبق','plate',320,20,15,20);
  f('egy','فاصوليا بالصلصة','Green beans stew','طبق','plate',200,6,18,12);
  f('egy','مسقعة','Moussaka (eggplant)','طبق','plate',220,4,16,16);
  f('egy','محشي ورق عنب','Stuffed grape leaves','5 حبات','5 pieces',250,5,38,9);
  f('egy','محشي كرنب','Stuffed cabbage','3 حبات','3 pieces',230,5,34,8);
  f('egy','محشي كوسة / باذنجان','Stuffed zucchini/eggplant','3 حبات','3 pieces',270,6,36,11);
  f('egy','فتة بالأرز واللحمة','Fatta (rice, bread, meat)','طبق','plate',650,25,80,25);
  f('egy','مكرونة بشاميل','Macaroni béchamel','قطعة','piece',400,16,38,20);
  f('egy','طاجن أرز معمر','Creamy baked rice','طبق','plate',450,12,48,24);
  f('egy','مكرونة بالصلصة','Pasta with tomato sauce','طبق','plate',350,12,60,6);
  f('egy','شوربة عدس','Lentil soup','طبق','bowl',180,10,28,3);
  f('egy','شوربة خضار','Vegetable soup','طبق','bowl',90,3,14,2);
  f('egy','حمام محشي أرز','Stuffed pigeon (rice)','نصف حمامة','half pigeon',480,30,25,28);
  f('egy','كبدة إسكندراني (ساندوتش)','Alexandrian liver sandwich','ساندوتش','sandwich',430,22,38,20);
  f('egy','سجق (ساندوتش)','Sausage sandwich','ساندوتش','sandwich',520,18,38,32);
  f('egy','شاورما فراخ (ساندوتش)','Chicken shawarma sandwich','ساندوتش','sandwich',450,28,38,20);
  f('egy','شاورما لحم (ساندوتش)','Beef shawarma sandwich','ساندوتش','sandwich',520,26,38,28);
  f('egy','كفتة (ساندوتش)','Kofta sandwich','ساندوتش','sandwich',480,22,40,24);
  f('egy','ساندوتش فول','Ful sandwich','نصف رغيف بلدي','half baladi loaf',330,15,50,7);
  f('egy','ساندوتش طعمية','Ta\'ameya sandwich','ساندوتش','sandwich',400,13,50,17);
  f('egy','فطير مشلتت','Feteer meshaltet','ربع فطيرة','quarter',350,6,34,21);
  f('egy','بيتزا','Pizza','شريحة','slice',270,11,33,10);
  f('egy','برجر لحم','Beef burger','ساندوتش','sandwich',520,26,40,28);

  // ---- خبز ونشويات ----
  f('bread','عيش بلدي','Baladi bread','رغيف','loaf',240,8,50,1.5);
  f('bread','عيش بلدي (نصف رغيف)','Baladi bread (half)','نصف رغيف','half loaf',120,4,25,0.8);
  f('bread','عيش فينو','Fino bread','رغيفة','loaf',160,5,31,2);
  f('bread','عيش شامي','Shami / pita','رغيف','loaf',165,5.5,33,0.7);
  f('bread','توست أبيض','White toast','شريحة','slice',70,2.5,13,1);
  f('bread','توست أسمر','Whole-wheat toast','شريحة','slice',75,3.5,13,1);
  f('bread','أرز أبيض مطبوخ','White rice, cooked','كوب (160 جم)','cup (160 g)',205,4,45,0.4);
  f('bread','أرز بالشعرية','Rice with vermicelli','كوب','cup',240,5,46,4);
  f('bread','مكرونة مسلوقة','Pasta, boiled','كوب (140 جم)','cup (140 g)',220,8,43,1.3);
  f('bread','بطاطس مسلوقة','Boiled potato','حبة متوسطة','medium',130,3,30,0.2);
  f('bread','بطاطس مقلية','French fries','طبق صغير (100 جم)','small (100 g)',310,3.5,40,15);
  f('bread','بطاطس محمرة بالفرن','Oven-roasted potatoes','150 جم','150 g',190,4,32,5);
  f('bread','بطاطا مشوية','Baked sweet potato','حبة متوسطة','medium',170,3,39,0.3);
  f('bread','ذرة مشوية','Grilled corn','كوز','cob',150,5,32,2);
  f('bread','عدس مطبوخ','Lentils, cooked','كوب','cup',230,18,40,0.8);
  f('bread','حمص مسلوق','Chickpeas, boiled','كوب','cup',270,15,45,4);
  f('bread','شوفان','Oats, dry','نصف كوب (40 جم)','1/2 cup (40 g)',150,5,27,2.5);
  f('bread','كورن فليكس بلبن','Corn flakes with milk','طبق','bowl',280,10,50,4);
  f('bread','بقسماط / جراهام','Rusk / Graham cracker','قطعة','piece',45,1,8,1);

  // ---- بروتين ----
  f('prot','صدر فراخ مشوي','Grilled chicken breast','150 جم','150 g',250,46,0,5.5);
  f('prot','فخذة فراخ مشوية (بالجلد)','Grilled chicken thigh (skin on)','قطعة 150 جم','150 g',330,30,0,22);
  f('prot','فراخ مقلية / بروستد','Fried chicken','قطعة','piece',300,20,10,20);
  f('prot','فراخ مسلوقة','Boiled chicken','100 جم','100 g',165,31,0,3.6);
  f('prot','لحم مشوي / كباب','Grilled beef / kebab','100 جم','100 g',280,25,0,19);
  f('prot','كفتة مشوية','Grilled kofta','100 جم','100 g',260,18,3,19);
  f('prot','لحم مسلوق','Boiled beef','100 جم','100 g',250,26,0,15);
  f('prot','كبدة مطبوخة','Cooked liver','100 جم','100 g',180,26,3,6);
  f('prot','سمك مشوي','Grilled fish','150 جم','150 g',200,35,0,6);
  f('prot','سمك مقلي','Fried fish','150 جم','150 g',330,30,10,18);
  f('prot','جمبري','Shrimp','100 جم','100 g',100,24,0.2,0.3);
  f('prot','تونة معلبة (بالمياه)','Canned tuna (in water)','علبة صغيرة (100 جم)','small can (100 g)',120,26,0,1);
  f('prot','مسحوق بروتين (واي)','Whey protein','سكوب','scoop',120,24,3,1.5);
  f('prot','بيضة مسلوقة','Boiled egg','بيضة','egg',78,6,0.6,5);
  f('prot','بيضة مقلية','Fried egg','بيضة','egg',95,6,0.5,7.5);
  f('prot','أومليت (بيضتين)','Omelette (2 eggs)','أومليت','omelette',190,12,1,15);
  f('prot','بياض بيض','Egg white','بياضة','white',17,3.6,0.2,0);

  // ---- ألبان ----
  f('dairy','لبن كامل الدسم','Whole milk','كوب (240 مل)','cup (240 ml)',150,8,12,8);
  f('dairy','لبن خالي الدسم','Skim milk','كوب (240 مل)','cup (240 ml)',90,8,12,0.5);
  f('dairy','زبادي كامل الدسم','Plain yogurt','علبة (200 جم)','tub (200 g)',120,7,9,6);
  f('dairy','زبادي يوناني','Greek yogurt','علبة (170 جم)','tub (170 g)',100,17,6,0.7);
  f('dairy','جبنة بيضاء (دمياطي)','White cheese (Domiati)','30 جم','30 g',75,4,1,6);
  f('dairy','جبنة رومي','Roumy cheese','30 جم','30 g',110,7,0.5,9);
  f('dairy','جبنة قريش','Cottage / Areesh cheese','100 جم','100 g',100,12,3,4);
  f('dairy','جبنة مثلثات','Cheese triangle','مثلث','triangle',40,2,1,3.2);
  f('dairy','قشطة','Qishta (clotted cream)','30 جم','30 g',120,1,1,13);
  f('dairy','لبنة','Labneh','ملعقتان كبيرتان','2 tbsp',70,3,3,5);
  f('dairy','لبن رايب','Rayeb (soured milk)','كوب','cup',130,7,10,7);

  // ---- خضار ----
  f('veg','سلطة خضراء','Green salad','طبق','bowl',50,2,8,2);
  f('veg','طماطم','Tomato','حبة','piece',22,1,4.8,0.2);
  f('veg','خيار','Cucumber','حبة','piece',15,0.7,3.6,0.1);
  f('veg','جزر','Carrot','حبة','piece',25,0.6,6,0.1);
  f('veg','فلفل رومي','Bell pepper','حبة','piece',30,1,7,0.3);
  f('veg','بروكلي مسلوق','Broccoli, boiled','كوب','cup',55,3.7,11,0.6);
  f('veg','سبانخ مطبوخة','Spinach, cooked','كوب','cup',41,5,7,0.5);
  f('veg','خضار سوتيه','Sautéed vegetables','طبق','plate',120,3,14,6);
  f('veg','باذنجان مشوي','Grilled eggplant','كوب','cup',35,1,9,0.2);
  f('veg','كوسة مطبوخة','Cooked zucchini','كوب','cup',30,2,6,0.4);

  // ---- فاكهة ----
  f('fruit','موز','Banana','حبة متوسطة','medium',105,1.3,27,0.4);
  f('fruit','تفاح','Apple','حبة متوسطة','medium',95,0.5,25,0.3);
  f('fruit','برتقال','Orange','حبة','medium',62,1.2,15,0.2);
  f('fruit','مانجو','Mango','كوب','cup',100,1.4,25,0.6);
  f('fruit','عنب','Grapes','كوب','cup',104,1,27,0.2);
  f('fruit','بطيخ','Watermelon','شريحة كبيرة','large slice',85,1.7,21,0.4);
  f('fruit','شمام','Cantaloupe','كوب','cup',54,1.3,13,0.3);
  f('fruit','جوافة','Guava','حبة كبيرة','large',68,2.6,14,1);
  f('fruit','رمان','Pomegranate','كوب حبوب','cup of seeds',144,3,32,2);
  f('fruit','فراولة','Strawberries','كوب','cup',48,1,11.5,0.5);
  f('fruit','تين طازج','Fresh fig','حبة','piece',37,0.4,10,0.15);
  f('fruit','خوخ','Peach','حبة','medium',58,1.4,14,0.4);
  f('fruit','كمثرى','Pear','حبة','medium',101,0.6,27,0.2);
  f('fruit','مشمش','Apricot','حبة','piece',17,0.5,4,0.1);
  f('fruit','تمر','Dates','حبة','piece',23,0.2,6,0);
  f('fruit','زبيب','Raisins','ملعقة كبيرة','tbsp',30,0.3,8,0);

  // ---- دهون وإضافات ----
  f('fat','زيت','Oil','ملعقة كبيرة','tbsp',120,0,0,14);
  f('fat','زبدة','Butter','ملعقة كبيرة','tbsp',100,0,0,11.5);
  f('fat','سمن بلدي','Ghee','ملعقة كبيرة','tbsp',120,0,0,14);
  f('fat','طحينة','Tahini','ملعقة كبيرة','tbsp',90,2.5,3,8);
  f('fat','زبدة فول سوداني','Peanut butter','ملعقة كبيرة','tbsp',95,4,3,8);
  f('fat','عسل نحل','Honey','ملعقة كبيرة','tbsp',64,0,17,0);
  f('fat','عسل أسود','Black honey (molasses)','ملعقة كبيرة','tbsp',60,0,15,0);
  f('fat','مربى','Jam','ملعقة كبيرة','tbsp',50,0,13,0);
  f('fat','سكر','Sugar','ملعقة صغيرة','tsp',16,0,4,0);
  f('fat','لوز','Almonds','30 جم','30 g',170,6,6,15);
  f('fat','فول سوداني','Peanuts','30 جم','30 g',170,7,5,14.5);
  f('fat','كاجو','Cashews','30 جم','30 g',165,5,9,13);
  f('fat','عين جمل / جوز','Walnuts','30 جم','30 g',195,4.5,4,19);
  f('fat','لب (أبيض/سوبر)','Roasted seeds','30 جم','30 g',165,8,5,14);
  f('fat','حمص بالطحينة','Hummus','ملعقتان كبيرتان','2 tbsp',70,2,5,5);
  f('fat','أفوكادو','Avocado','نصف حبة','half',160,2,9,15);

  // ---- حلويات ----
  f('sweet','كنافة بالمكسرات','Kunafa with nuts','قطعة (100 جم)','piece (100 g)',400,6,50,20);
  f('sweet','بسبوسة','Basbousa','قطعة (80 جم)','piece (80 g)',290,3,43,12);
  f('sweet','بقلاوة','Baklava','قطعة','piece',230,3.5,25,13);
  f('sweet','قطايف بالمكسرات','Qatayef with nuts','قطعة','piece',220,3,28,10);
  f('sweet','أم علي','Om Ali','طبق صغير (200 جم)','small bowl (200 g)',450,9,50,24);
  f('sweet','رز بلبن','Rice pudding','طبق صغير (150 جم)','small bowl (150 g)',220,5,38,5.5);
  f('sweet','مهلبية','Muhallabia','طبق (150 جم)','bowl (150 g)',180,4,30,5);
  f('sweet','كحك العيد','Eid kahk','قطعة','piece',190,2.5,22,10.5);
  f('sweet','غريبة','Ghorayeba','قطعة','piece',130,1.5,13,8);
  f('sweet','بيتي فور','Petit four','قطعة','piece',90,1,12,4);
  f('sweet','لقمة القاضي','Luqmat el-qadi','قطعة','piece',80,1,11,3.5);
  f('sweet','حلاوة طحينية','Halawa tahiniya','50 جم','50 g',260,6,26,15);
  f('sweet','كيك','Cake','قطعة (80 جم)','slice (80 g)',300,4,40,14);
  f('sweet','كرواسون','Croissant','قطعة','piece',230,5,26,12);
  f('sweet','دونات','Doughnut','قطعة','piece',250,3,30,14);
  f('sweet','آيس كريم','Ice cream','كوب (100 جم)','scoop (100 g)',210,3.5,24,11);
  f('sweet','شيكولاتة','Chocolate','40 جم','40 g',215,2.5,23,12.5);
  f('sweet','بسكويت مارى','Marie biscuit','قطعة','piece',30,0.5,5,1);

  // ---- سناكس ----
  f('snack','شيبسي','Potato chips','كيس صغير (30 جم)','small bag (30 g)',160,2,15,10);
  f('snack','فشار','Popcorn','كوب','cup',55,2,11,0.6);
  f('snack','ويفر / بسكويت بالشيكولاتة','Chocolate wafer','قطعة','piece',110,1.5,15,5);
  f('snack','بيتزا صغيرة / فطيرة جبنة','Cheese pie','قطعة','piece',280,8,28,15);
  f('snack','سمبوسك','Samosa','قطعة','piece',130,4,13,7);
  f('snack','لب وسوداني مشكل','Mixed nuts','30 جم','30 g',175,6,6,15);

  // ---- مشروبات ----
  f('drink','مياه','Water','كوب','glass',0,0,0,0);
  f('drink','شاي بدون سكر','Tea, no sugar','كوب','cup',2,0,0.5,0);
  f('drink','شاي بملعقة سكر','Tea, 1 tsp sugar','كوب','cup',18,0,4.5,0);
  f('drink','شاي بملعقتين سكر','Tea, 2 tsp sugar','كوب','cup',34,0,8.5,0);
  f('drink','قهوة سادة','Black coffee','فنجان','cup',2,0.3,0,0);
  f('drink','قهوة تركي (سكر وسط)','Turkish coffee (medium)','فنجان','cup',22,0.3,5,0);
  f('drink','نسكافيه 3 في 1','3-in-1 instant coffee','كوب','cup',90,1,15,3);
  f('drink','كابتشينو','Cappuccino','متوسط','medium',120,6,10,6);
  f('drink','لاتيه','Latte','كبير','large',190,10,15,9);
  f('drink','كركديه (بسكر)','Hibiscus (sweetened)','كوب','cup',40,0,10,0);
  f('drink','عرقسوس / تمر هندي','Licorice / Tamarind drink','كوب','cup',100,0,25,0);
  f('drink','سحلب','Sahlab','كوب','cup',250,6,40,8);
  f('drink','عصير برتقال طازج','Fresh orange juice','كوب (250 مل)','cup (250 ml)',112,1.7,26,0.5);
  f('drink','عصير قصب','Sugarcane juice','كوب (250 مل)','cup (250 ml)',180,0,45,0);
  f('drink','عصير مانجو (شعبي)','Mango juice (shop)','كوب (250 مل)','cup (250 ml)',200,1,50,0.5);
  f('drink','عصير معلب','Boxed juice','علبة (235 مل)','box (235 ml)',110,0,27,0);
  f('drink','مياه غازية (كولا)','Cola','علبة (330 مل)','can (330 ml)',139,0,35,0);
  f('drink','مياه غازية دايت','Diet soda','علبة','can',0,0,0,0);
  f('drink','حليب بالشيكولاتة','Chocolate milk','كوب','cup',210,8,30,7);
  f('drink','مشروب طاقة','Energy drink','علبة (250 مل)','can (250 ml)',110,0,28,0);

  // ---- exercises ----
  const ex = [];
  const e = (id, grp, ar, en) => ex.push({ id, grp, ar, en });
  // chest
  e('bench','chest','بنش برس بار','Barbell bench press');
  e('incbench','chest','بنش مائل بار','Incline barbell press');
  e('dbpress','chest','ضغط دامبل','Dumbbell bench press');
  e('incdb','chest','ضغط دامبل مائل','Incline dumbbell press');
  e('fly','chest','فلاي دامبل','Dumbbell fly');
  e('cablefly','chest','كروس أوفر (كابل)','Cable crossover');
  e('chestpress','chest','ضغط صدر ماكينة','Chest press machine');
  e('pecdeck','chest','بيك ديك','Pec deck');
  e('dips','chest','متوازي (صدر)','Chest dips');
  e('pushup','chest','ضغط (Push-up)','Push-up');
  // back
  e('deadlift','back','ديدلفت','Deadlift');
  e('pullup','back','عقلة','Pull-up');
  e('latpd','back','سحب أمامي (لات)','Lat pulldown');
  e('row','back','سحب بار منحني','Barbell row');
  e('dbrow','back','سحب دامبل','One-arm dumbbell row');
  e('cablerow','back','سحب كابل جالس','Seated cable row');
  e('tbar','back','تي بار','T-bar row');
  e('shrug','back','شراجز (ترابيس)','Shrugs');
  e('hyper','back','أسفل الظهر (هايبر)','Back extension');
  // shoulders
  e('ohp','shoulders','ضغط كتف بار','Overhead press');
  e('dbshoulder','shoulders','ضغط كتف دامبل','Dumbbell shoulder press');
  e('arnold','shoulders','أرنولد برس','Arnold press');
  e('lateral','shoulders','رفرفة جانبي','Lateral raise');
  e('frontraise','shoulders','رفرفة أمامي','Front raise');
  e('reardelt','shoulders','رفرفة خلفي','Rear delt fly');
  e('facepull','shoulders','فيس بول','Face pull');
  e('uprow','shoulders','سحب عمودي','Upright row');
  // biceps
  e('barcurl','biceps','بايسبس بار','Barbell curl');
  e('dbcurl','biceps','بايسبس دامبل','Dumbbell curl');
  e('hammer','biceps','هامر','Hammer curl');
  e('preacher','biceps','بريتشر كيرل','Preacher curl');
  e('cablecurl','biceps','بايسبس كابل','Cable curl');
  // triceps
  e('pushdown','triceps','ترايسبس كابل (بوش داون)','Triceps pushdown');
  e('skull','triceps','سكول كراشر','Skull crusher');
  e('overtri','triceps','ترايسبس فوق الرأس','Overhead triceps extension');
  e('cgbench','triceps','بنش ضيق','Close-grip bench');
  e('kickback','triceps','كيك باك','Triceps kickback');
  e('benchdips','triceps','ديبس على الدكة','Bench dips');
  // legs
  e('squat','legs','سكوات بار','Barbell squat');
  e('legpress','legs','ليج برس','Leg press');
  e('hack','legs','هاك سكوات','Hack squat');
  e('lunge','legs','لانجز','Lunges');
  e('bulg','legs','بلغاري سبلت سكوات','Bulgarian split squat');
  e('goblet','legs','جوبلت سكوات','Goblet squat');
  e('rdl','legs','رومانيان ديدلفت','Romanian deadlift');
  e('legext','legs','ليج إكستنشن','Leg extension');
  e('legcurl','legs','ليج كيرل','Leg curl');
  e('calf','legs','سمانة','Calf raise');
  // glutes
  e('hipthrust','glutes','هيب ثراست','Hip thrust');
  e('glutebridge','glutes','جلوت بريدج','Glute bridge');
  e('cablekick','glutes','ركلة خلفية كابل','Cable glute kickback');
  // abs
  e('crunch','abs','كرانش','Crunch');
  e('plank','abs','بلانك (ثواني)','Plank (sec)');
  e('legraise','abs','رفع أرجل','Leg raise');
  e('twist','abs','روسيان تويست','Russian twist');
  e('cablecrunch','abs','كرانش كابل','Cable crunch');
  e('abwheel','abs','عجلة بطن','Ab wheel');
  e('mclimb','abs','ماونتن كلايمبر','Mountain climbers');
  // home / bodyweight
  e('bwsquat','home','سكوات بوزن الجسم','Bodyweight squat');
  e('burpee','home','بيربي','Burpee');
  e('jjack','home','جامبينج جاك','Jumping jacks');
  e('wallsit','home','جلسة الحائط (ثواني)','Wall sit (sec)');
  e('pike','home','ضغط كتف بايك','Pike push-up');
  e('superman','home','سوبرمان','Superman');

  const groups = [
    { id: 'chest', ar: 'صدر', en: 'Chest' },
    { id: 'back', ar: 'ظهر', en: 'Back' },
    { id: 'shoulders', ar: 'أكتاف', en: 'Shoulders' },
    { id: 'biceps', ar: 'بايسبس', en: 'Biceps' },
    { id: 'triceps', ar: 'ترايسبس', en: 'Triceps' },
    { id: 'legs', ar: 'أرجل', en: 'Legs' },
    { id: 'glutes', ar: 'مؤخرة', en: 'Glutes' },
    { id: 'abs', ar: 'بطن', en: 'Abs' },
    { id: 'home', ar: 'منزلي', en: 'Home' }
  ];

  const cats = [
    { id: 'egy', ar: 'أطباق مصرية', en: 'Egyptian dishes' },
    { id: 'bread', ar: 'خبز ونشويات', en: 'Bread & starches' },
    { id: 'prot', ar: 'لحوم وبروتين', en: 'Meat & protein' },
    { id: 'dairy', ar: 'ألبان', en: 'Dairy' },
    { id: 'veg', ar: 'خضار', en: 'Vegetables' },
    { id: 'fruit', ar: 'فاكهة', en: 'Fruit' },
    { id: 'fat', ar: 'دهون وإضافات', en: 'Fats & extras' },
    { id: 'sweet', ar: 'حلويات', en: 'Sweets' },
    { id: 'snack', ar: 'سناكس', en: 'Snacks' },
    { id: 'drink', ar: 'مشروبات', en: 'Drinks' }
  ];

  // Plan templates. Days use JS getDay(): 0=Sun ... 6=Sat. [exerciseId, sets, reps]
  const X = (id, s, r) => [id, s, r];
  const templates = [
    {
      id: 'ppl', ar: 'Push / Pull / Legs (6 أيام)', en: 'Push / Pull / Legs (6 days)',
      days: {
        6: { ar: 'Push (صدر + كتف + ترايسبس)', en: 'Push', ex: [X('bench',4,8),X('incdb',3,10),X('dbshoulder',3,10),X('lateral',3,15),X('pushdown',3,12),X('overtri',3,12)] },
        0: { ar: 'Pull (ظهر + بايسبس)', en: 'Pull', ex: [X('deadlift',3,5),X('latpd',4,10),X('cablerow',3,10),X('facepull',3,15),X('barcurl',3,10),X('hammer',3,12)] },
        1: { ar: 'Legs (أرجل)', en: 'Legs', ex: [X('squat',4,8),X('legpress',3,12),X('rdl',3,10),X('legext',3,12),X('legcurl',3,12),X('calf',4,15)] },
        2: { ar: 'Push', en: 'Push', ex: [X('ohp',4,8),X('dbpress',3,10),X('cablefly',3,12),X('lateral',3,15),X('skull',3,10),X('pushdown',3,12)] },
        3: { ar: 'Pull', en: 'Pull', ex: [X('pullup',4,8),X('row',3,10),X('dbrow',3,12),X('reardelt',3,15),X('dbcurl',3,12),X('cablecurl',3,12)] },
        4: { ar: 'Legs', en: 'Legs', ex: [X('hack',4,10),X('lunge',3,12),X('hipthrust',3,10),X('legcurl',3,12),X('calf',4,15),X('crunch',3,20)] },
        5: { ar: 'راحة', en: 'Rest', ex: [] }
      }
    },
    {
      id: 'ul', ar: 'Upper / Lower (4 أيام)', en: 'Upper / Lower (4 days)',
      days: {
        6: { ar: 'Upper (علوي)', en: 'Upper', ex: [X('bench',4,8),X('row',4,8),X('ohp',3,10),X('latpd',3,10),X('dbcurl',3,12),X('pushdown',3,12)] },
        0: { ar: 'Lower (سفلي)', en: 'Lower', ex: [X('squat',4,8),X('rdl',3,10),X('legpress',3,12),X('legcurl',3,12),X('calf',4,15),X('plank',3,45)] },
        1: { ar: 'راحة', en: 'Rest', ex: [] },
        2: { ar: 'Upper', en: 'Upper', ex: [X('incdb',4,10),X('pullup',4,8),X('dbshoulder',3,10),X('cablerow',3,12),X('hammer',3,12),X('skull',3,10)] },
        3: { ar: 'Lower', en: 'Lower', ex: [X('deadlift',3,5),X('hack',3,10),X('lunge',3,12),X('legext',3,12),X('hipthrust',3,10),X('crunch',3,20)] },
        4: { ar: 'راحة', en: 'Rest', ex: [] },
        5: { ar: 'راحة', en: 'Rest', ex: [] }
      }
    },
    {
      id: 'fb', ar: 'Full Body (3 أيام) — للمبتدئين', en: 'Full Body (3 days) — beginner',
      days: {
        6: { ar: 'Full Body A', en: 'Full Body A', ex: [X('squat',3,8),X('bench',3,8),X('row',3,8),X('dbshoulder',2,10),X('plank',3,40)] },
        0: { ar: 'راحة', en: 'Rest', ex: [] },
        1: { ar: 'Full Body B', en: 'Full Body B', ex: [X('legpress',3,10),X('dbpress',3,10),X('latpd',3,10),X('lateral',2,15),X('dbcurl',2,12),X('pushdown',2,12)] },
        2: { ar: 'راحة', en: 'Rest', ex: [] },
        3: { ar: 'Full Body C', en: 'Full Body C', ex: [X('rdl',3,8),X('incdb',3,10),X('cablerow',3,10),X('lunge',2,12),X('crunch',3,20)] },
        4: { ar: 'راحة', en: 'Rest', ex: [] },
        5: { ar: 'راحة', en: 'Rest', ex: [] }
      }
    },
    {
      id: 'bro', ar: 'تقسيمة 5 أيام (عضلة في اليوم)', en: '5-day body-part split',
      days: {
        6: { ar: 'صدر', en: 'Chest', ex: [X('bench',4,8),X('incdb',4,10),X('fly',3,12),X('cablefly',3,12),X('dips',3,10)] },
        0: { ar: 'ظهر', en: 'Back', ex: [X('deadlift',3,5),X('pullup',4,8),X('row',4,10),X('cablerow',3,12),X('shrug',3,12)] },
        1: { ar: 'أرجل', en: 'Legs', ex: [X('squat',4,8),X('legpress',4,12),X('rdl',3,10),X('legext',3,12),X('legcurl',3,12),X('calf',4,15)] },
        2: { ar: 'كتف + بطن', en: 'Shoulders + Abs', ex: [X('ohp',4,8),X('lateral',4,15),X('reardelt',3,15),X('shrug',3,12),X('cablecrunch',3,15),X('legraise',3,15)] },
        3: { ar: 'دراعات', en: 'Arms', ex: [X('barcurl',4,10),X('skull',4,10),X('hammer',3,12),X('pushdown',3,12),X('preacher',3,12),X('overtri',3,12)] },
        4: { ar: 'راحة', en: 'Rest', ex: [] },
        5: { ar: 'راحة', en: 'Rest', ex: [] }
      }
    },
    {
      id: 'home', ar: 'تمارين منزلية (بدون أدوات)', en: 'Home workout (no equipment)',
      days: {
        6: { ar: 'جسم كامل', en: 'Full body', ex: [X('bwsquat',4,20),X('pushup',4,12),X('glutebridge',3,15),X('plank',3,40),X('mclimb',3,30)] },
        0: { ar: 'راحة', en: 'Rest', ex: [] },
        1: { ar: 'علوي + بطن', en: 'Upper + Abs', ex: [X('pushup',4,12),X('pike',3,8),X('superman',3,15),X('crunch',3,20),X('legraise',3,12)] },
        2: { ar: 'راحة', en: 'Rest', ex: [] },
        3: { ar: 'أرجل + كارديو', en: 'Legs + Cardio', ex: [X('lunge',3,12),X('wallsit',3,40),X('burpee',3,10),X('jjack',3,40)] },
        4: { ar: 'راحة', en: 'Rest', ex: [] },
        5: { ar: 'راحة', en: 'Rest', ex: [] }
      }
    }
  ];

  window.DATA = { foods, exercises: ex, groups, cats, templates };
})();
