/* Health: measurements + medical history */
(function () {
  'use strict';
  const A = window.App;
  const H = () => A.S.health, M = () => A.S.medical;
  const cls = (c) => ({ ok: 'okc', warn: 'warnc', bad: 'badc' }[c] || '');

  A.bpClass = (s, d) => {
    if (s > 180 || d > 120) return [A.T('أزمة ضغط — اطلب مساعدة طبية', 'Hypertensive crisis — seek care'), 'bad'];
    if (s >= 140 || d >= 90) return [A.T('ارتفاع — مرحلة 2', 'High — stage 2'), 'bad'];
    if (s >= 130 || d >= 80) return [A.T('ارتفاع — مرحلة 1', 'High — stage 1'), 'warn'];
    if (s >= 120) return [A.T('مرتفع قليلًا', 'Elevated'), 'warn'];
    if (s < 90 || d < 60) return [A.T('منخفض', 'Low'), 'warn'];
    return [A.T('طبيعي', 'Normal'), 'ok'];
  };
  const GCTX = { fast: ['صائم', 'Fasting'], post: ['بعد الأكل بساعتين', '2h after meal'], rand: ['عشوائي', 'Random'], bed: ['قبل النوم', 'Bedtime'] };
  A.gluClass = (v, ctx) => {
    if (v < 70) return [A.T('منخفض', 'Low'), 'bad'];
    if (ctx === 'fast') return v < 100 ? [A.T('طبيعي', 'Normal'), 'ok'] : v < 126 ? [A.T('مرتفع (ما قبل السكري)', 'Prediabetes range'), 'warn'] : [A.T('مرتفع (نطاق السكري)', 'Diabetes range'), 'bad'];
    return v < 140 ? [A.T('طبيعي', 'Normal'), 'ok'] : v < 200 ? [A.T('مرتفع قليلًا', 'Elevated'), 'warn'] : [A.T('مرتفع جدًا', 'High'), 'bad'];
  };
  A.bodyFat = () => {
    const b = [...H().body].reverse(); const p = A.S.profile;
    const w = b.find((x) => x.waist), n = b.find((x) => x.neck), hp = b.find((x) => x.hip);
    if (!w || !n) return null;
    const waist = w.waist, neck = n.neck, h = p.height;
    let bf;
    if (p.sex === 'm') { if (waist - neck <= 0) return null; bf = 495 / (1.0324 - 0.19077 * Math.log10(waist - neck) + 0.15456 * Math.log10(h)) - 450; }
    else { if (!hp || waist + hp.hip - neck <= 0) return null; bf = 495 / (1.29579 - 0.35004 * Math.log10(waist + hp.hip - neck) + 0.221 * Math.log10(h)) - 450; }
    return isFinite(bf) && bf > 2 && bf < 60 ? bf : null;
  };

  A.views.health = () => {
    const tabs = [['meas', A.T('القياسات', 'Measurements')], ['med', A.T('التاريخ المرضي', 'Medical history')]];
    let h = `<div class="top"><h1>${A.T('صحتي', 'My Health')}</h1></div><div class="seg">${tabs.map(([id, l]) => `<button class="${A.ui.htab === id ? 'on' : ''}" data-act="htab" data-t="${id}">${l}</button>`).join('')}</div>`;
    h += A.ui.htab === 'meas' ? measView() : medView();
    return h + '<div class="pad"></div>';
  };
  A.act.htab = (el) => { A.ui.htab = el.dataset.t; A.render(); };

  function recent(type, fmt, n) {
    const arr = H()[type].slice(-(n || 4)).reverse();
    return arr.map((x) => `<button class="item" data-act="delHealth" data-type="${type}" data-id="${x.id}"><span class="in"><span>${fmt(x)}</span></span>${A.ic('trash', 'mut')}</button>`).join('');
  }
  function measView() {
    const p = A.S.profile, W = H().weight, lw = A.lastWeight(), bmi = A.bmi(lw, p.height), bc = A.bmiClass(bmi);
    const wpts = W.map((x) => ({ t: A.pk(x.d).getTime(), y: x.v }));
    const diff = W.length > 1 ? W[W.length - 1].v - W[0].v : 0;
    let h = `<div class="card"><div class="mh"><div><b>${A.T('الوزن', 'Weight')}</b><small class="mut"> · ${A.T('الهدف', 'goal')} ${A.fmt(p.goalWeight, 1)}</small></div><button class="btn sm" data-act="addH" data-type="weight">${A.ic('plus')} ${A.T('تسجيل', 'Log')}</button></div>
      <div class="stats3"><div><b>${A.fmt(lw, 1)}</b><small>${A.T('كجم الآن', 'kg now')}</small></div><div><b class="${diff <= 0 ? 'okc' : 'warnc'}">${diff > 0 ? '+' : ''}${A.fmt(diff, 1)}</b><small>${A.T('التغيّر', 'change')}</small></div><div><b class="${cls(bc[1])}">${A.fmt(bmi, 1)}</b><small>BMI · ${bc[0]}</small></div></div>${A.line(wpts, { goal: p.goalWeight, dec: 1 })}${recent('weight', (x) => `${A.esc(A.dshort(x.d))} — <b>${A.fmt(x.v, 1)}</b> ${A.T('كجم', 'kg')}`, 3)}</div>`;
    // BP
    const bp = H().bp, lb = bp[bp.length - 1];
    h += `<div class="card"><div class="mh"><div><b>${A.T('ضغط الدم', 'Blood pressure')}</b></div><button class="btn sm" data-act="addH" data-type="bp">${A.ic('plus')} ${A.T('تسجيل', 'Log')}</button></div>`;
    if (lb) { const c = A.bpClass(lb.sys, lb.dia); h += `<div class="bigread"><b>${A.n(lb.sys + '/' + lb.dia)}</b><span class="chip ${cls(c[1])}">${c[0]}</span>${lb.pulse ? `<small class="mut">${A.T('نبض', 'pulse')} ${lb.pulse}</small>` : ''}</div>${A.line(bp.map((x) => ({ t: A.pk(x.d).getTime() + 1, y: x.sys })), { dec: 0, h: 110 })}`; } else h += `<div class="empty">${A.T('لا توجد قراءات', 'No readings')}</div>`;
    h += recent('bp', (x) => `${A.esc(A.dshort(x.d))} ${A.esc(x.t || '')} — <b>${A.n(x.sys + '/' + x.dia)}</b>${x.pulse ? ' · ' + x.pulse : ''}`) + `</div>`;
    // glucose
    const gl = H().glu, lg = gl[gl.length - 1];
    h += `<div class="card"><div class="mh"><div><b>${A.T('سكر الدم', 'Blood glucose')}</b><small class="mut"> mg/dL</small></div><button class="btn sm" data-act="addH" data-type="glu">${A.ic('plus')} ${A.T('تسجيل', 'Log')}</button></div>`;
    if (lg) { const c = A.gluClass(lg.v, lg.ctx); h += `<div class="bigread"><b>${lg.v}</b><span class="chip ${cls(c[1])}">${c[0]}</span><small class="mut">${A.T(GCTX[lg.ctx][0], GCTX[lg.ctx][1])}</small></div>${A.line(gl.map((x) => ({ t: A.pk(x.d).getTime() + 1, y: x.v })), { dec: 0, h: 110 })}`; } else h += `<div class="empty">${A.T('لا توجد قراءات', 'No readings')}</div>`;
    h += recent('glu', (x) => `${A.esc(A.dshort(x.d))} ${A.esc(x.t || '')} — <b>${x.v}</b> · ${A.T(GCTX[x.ctx][0], GCTX[x.ctx][1])}`) + `</div>`;
    // body
    const bd = H().body, lbd = bd[bd.length - 1], bf = A.bodyFat();
    h += `<div class="card"><div class="mh"><div><b>${A.T('قياسات الجسم (سم)', 'Body measurements (cm)')}</b></div><button class="btn sm" data-act="addH" data-type="body">${A.ic('plus')} ${A.T('تسجيل', 'Log')}</button></div>`;
    if (lbd) { const F = [['waist', 'الوسط', 'Waist'], ['hip', 'الأرداف', 'Hip'], ['neck', 'الرقبة', 'Neck'], ['chest', 'الصدر', 'Chest'], ['arm', 'الذراع', 'Arm'], ['thigh', 'الفخذ', 'Thigh']]; h += `<div class="chips">${F.filter(([k]) => lbd[k]).map(([k, a, e]) => `<span class="chip">${A.T(a, e)} ${lbd[k]}</span>`).join('')}</div>`; }
    h += bf ? `<p>${A.T('نسبة الدهون التقديرية (Navy):', 'Est. body fat (Navy):')} <b>${A.fmt(bf, 1)}%</b></p><p class="note">${A.T('تحتاج الوسط + الرقبة (+ الأرداف للسيدات). تقدير تقريبي.', 'Needs waist + neck (+ hip for women). Rough estimate.')}</p>` : `<p class="note">${A.T('سجّل الوسط والرقبة (والأرداف للسيدات) لتقدير نسبة الدهون.', 'Log waist & neck (and hip for women) to estimate body fat.')}</p>`;
    h += recent('body', (x) => `${A.esc(A.dshort(x.d))} — ${[x.waist && 'W' + x.waist, x.hip && 'H' + x.hip, x.neck && 'N' + x.neck, x.chest && 'C' + x.chest].filter(Boolean).join(' ')}`, 3) + `</div>`;
    // sleep
    const sl = H().sleep, l7 = sl.slice(-7), avg = l7.length ? l7.reduce((s, x) => s + x.h, 0) / l7.length : 0;
    h += `<div class="card"><div class="mh"><div><b>${A.T('النوم', 'Sleep')}</b>${l7.length ? `<small class="mut"> · ${A.T('المتوسط', 'avg')} ${A.fmt(avg, 1)} ${A.T('ساعة', 'h')}</small>` : ''}</div><button class="btn sm" data-act="addH" data-type="sleep">${A.ic('plus')} ${A.T('تسجيل', 'Log')}</button></div>${l7.length ? A.bars(l7.map((x) => ({ l: A.pk(x.d).getDate(), v: x.h })), { color: 'var(--acc3)', h: 110 }) : ''}${recent('sleep', (x) => `${A.esc(A.dshort(x.d))} — <b>${x.h}</b> ${A.T('ساعة', 'h')} · ${'★'.repeat(x.q || 0)}`, 2)}</div>`;
    h += `<p class="note">${A.T('هذه الأدوات للمتابعة الشخصية ولا تغني عن استشارة الطبيب.', 'These tools are for personal tracking and do not replace medical advice.')}</p>`;
    return h;
  }

  const FORMS = {
    weight: { ar: 'تسجيل الوزن', en: 'Log weight', f: [['v', 'الوزن (كجم)', 'Weight (kg)', 0.1, 1]] },
    bp: { ar: 'تسجيل ضغط الدم', en: 'Log blood pressure', f: [['sys', 'الانقباضي (العالي)', 'Systolic (top)', 1, 1], ['dia', 'الانبساطي (الواطي)', 'Diastolic (bottom)', 1, 1], ['pulse', 'النبض (اختياري)', 'Pulse (optional)', 1, 0]], time: 1 },
    glu: { ar: 'تسجيل سكر الدم', en: 'Log blood glucose', f: [['v', 'القراءة (mg/dL)', 'Reading (mg/dL)', 1, 1]], ctx: 1, time: 1 },
    body: { ar: 'قياسات الجسم', en: 'Body measurements', f: [['waist', 'الوسط (سم)', 'Waist (cm)', 0.5, 0], ['hip', 'الأرداف (سم)', 'Hip (cm)', 0.5, 0], ['neck', 'الرقبة (سم)', 'Neck (cm)', 0.5, 0], ['chest', 'الصدر (سم)', 'Chest (cm)', 0.5, 0], ['arm', 'الذراع (سم)', 'Arm (cm)', 0.5, 0], ['thigh', 'الفخذ (سم)', 'Thigh (cm)', 0.5, 0]] },
    sleep: { ar: 'تسجيل النوم', en: 'Log sleep', f: [['h', 'عدد الساعات', 'Hours slept', 0.25, 1]], q: 1 }
  };
  A.act.addH = (el) => {
    const type = el.dataset.type, c = FORMS[type];
    let f = `<label>${A.T('التاريخ', 'Date')}<input type="date" name="d" value="${A.today()}" required></label>`;
    if (c.time) f += `<label>${A.T('الوقت', 'Time')}<input type="time" name="t" value="${A.nowTime()}"></label>`;
    f += `<div class="g2">${c.f.map(([n, ar, en, step, req]) => `<label>${A.T(ar, en)}<input name="${n}" type="number" inputmode="decimal" step="${step}" ${req ? 'required' : ''} ${type === 'weight' && n === 'v' ? `value="${A.fmt(A.lastWeight(), 1)}"` : ''}></label>`).join('')}</div>`;
    if (c.ctx) f += `<label>${A.T('الحالة', 'Context')}<select name="ctx">${Object.entries(GCTX).map(([k, v]) => `<option value="${k}">${A.T(v[0], v[1])}</option>`).join('')}</select></label>`;
    if (c.q) f += `<label>${A.T('جودة النوم', 'Sleep quality')}<select name="q">${[5, 4, 3, 2, 1].map((n) => `<option value="${n}" ${n === 3 ? 'selected' : ''}>${'★'.repeat(n)}</option>`).join('')}</select></label>`;
    A.modal(A.T(c.ar, c.en), `<form data-frm="healthAdd" data-type="${type}" class="form">${f}<button class="btn full" type="submit">${A.T('حفظ', 'Save')}</button></form>`);
  };
  A.frm.healthAdd = (f, fd) => {
    const type = f.dataset.type, c = FORMS[type], e = { id: A.uid(), d: fd.get('d') || A.today() };
    if (c.time) e.t = fd.get('t') || '';
    c.f.forEach(([n]) => { const v = fd.get(n); if (v !== '' && v != null) e[n] = A.num(v); });
    if (c.ctx) e.ctx = fd.get('ctx');
    if (c.q) e.q = A.num(fd.get('q'), 3);
    let arr = H()[type];
    if (type === 'weight') { arr = arr.filter((x) => x.d !== e.d); A.S.health.weight = arr; A.S.profile.weight = e.v; }
    if (type === 'body' && !c.f.some(([n]) => e[n])) { A.toast(A.T('اكتب قياس واحد على الأقل', 'Enter at least one measurement')); return; }
    arr.push(e); arr.sort((a, b) => (a.d + (a.t || '')).localeCompare(b.d + (b.t || '')));
    A.S.health[type] = arr; A.save(); A.closeModal(); A.toast(A.T('تم الحفظ', 'Saved'));
  };
  A.act.delHealth = (el) => A.confirm(A.T('حذف هذه القراءة؟', 'Delete this entry?'), () => { const t = el.dataset.type; A.S.health[t] = H()[t].filter((x) => x.id !== el.dataset.id); A.save(); A.render(); });

  /* ================= medical history ================= */
  const SECS = [
    { k: 'conditions', ar: 'الأمراض والتشخيصات', en: 'Conditions & diagnoses', f: [['name', 'الاسم', 'Name', 'text', 1], ['since', 'منذ (سنة/تاريخ)', 'Since (year/date)', 'text'], ['notes', 'ملاحظات', 'Notes', 'area']] },
    { k: 'meds', ar: 'الأدوية', en: 'Medications', f: [['name', 'اسم الدواء', 'Medicine', 'text', 1], ['dose', 'الجرعة', 'Dose', 'text'], ['times', 'المواعيد (مثال: 08:00, 20:00)', 'Times (e.g. 08:00, 20:00)', 'text'], ['remind', 'ذكّرني بالمواعيد', 'Remind me', 'check'], ['notes', 'ملاحظات', 'Notes', 'area']] },
    { k: 'allergies', ar: 'الحساسية', en: 'Allergies', f: [['name', 'المسبب', 'Allergen', 'text', 1], ['reaction', 'رد الفعل', 'Reaction', 'text']] },
    { k: 'surgeries', ar: 'العمليات الجراحية', en: 'Surgeries', f: [['name', 'العملية', 'Procedure', 'text', 1], ['date', 'التاريخ', 'Date', 'text'], ['notes', 'ملاحظات', 'Notes', 'area']] },
    { k: 'family', ar: 'التاريخ العائلي', en: 'Family history', f: [['name', 'المرض', 'Condition', 'text', 1], ['who', 'القرابة', 'Relative', 'text'], ['notes', 'ملاحظات', 'Notes', 'area']] },
    { k: 'labs', ar: 'التحاليل والفحوصات', en: 'Lab results', f: [['name', 'التحليل', 'Test', 'text', 1], ['value', 'النتيجة', 'Result', 'text'], ['date', 'التاريخ', 'Date', 'date'], ['notes', 'ملاحظات', 'Notes', 'area']] },
    { k: 'visits', ar: 'زيارات الطبيب', en: 'Doctor visits', f: [['date', 'التاريخ', 'Date', 'date', 1], ['doctor', 'الطبيب / التخصص', 'Doctor / specialty', 'text'], ['notes', 'التشخيص / التعليمات', 'Diagnosis / instructions', 'area']] }
  ];
  const secOf = (k) => SECS.find((s) => s.k === k);
  const title = (s, it) => it[s.f[0][0]] || '';
  const sub = (s, it) => s.f.slice(1).filter(([n, , , t]) => t !== 'check' && it[n]).map(([n]) => it[n]).join(' · ');

  function medView() {
    const m = M();
    const bl = ['', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
    let h = `<div class="card sos"><div class="mh"><b>${A.T('بطاقة الطوارئ', 'Emergency card')}</b><span class="chip">${A.T('فصيلة الدم', 'Blood')}: <select data-chg="blood" class="inl">${bl.map((b) => `<option value="${b}" ${m.blood === b ? 'selected' : ''}>${b || '—'}</option>`).join('')}</select></span></div>
      <p><b>${A.T('حساسية', 'Allergies')}:</b> ${m.allergies.length ? m.allergies.map((x) => A.esc(x.name)).join('، ') : '—'}</p><p><b>${A.T('أمراض', 'Conditions')}:</b> ${m.conditions.length ? m.conditions.map((x) => A.esc(x.name)).join('، ') : '—'}</p><p><b>${A.T('أدوية', 'Medications')}:</b> ${m.meds.length ? m.meds.map((x) => A.esc(x.name + (x.dose ? ' ' + x.dose : ''))).join('، ') : '—'}</p></div>
      <div class="row gap"><button class="btn ghost grow sm" data-act="medCopy">${A.T('نسخ ملخص للطبيب', 'Copy summary')}</button><button class="btn ghost grow sm" data-act="medPrint">${A.ic('file')} ${A.T('طباعة / PDF', 'Print / PDF')}</button></div>`;
    for (const s of SECS) {
      const arr = m[s.k];
      h += `<div class="card"><div class="mh"><b>${A.T(s.ar, s.en)}</b><button class="ib acc" data-act="medAdd" data-k="${s.k}" aria-label="add">${A.ic('plus')}</button></div>`;
      if (!arr.length) h += `<div class="empty sm">${A.T('لا يوجد', 'None')}</div>`;
      arr.forEach((it) => { h += `<button class="item" data-act="medEdit" data-k="${s.k}" data-id="${it.id}"><span class="in">${A.esc(title(s, it))}${s.k === 'meds' && it.remind ? ' 🔔' : ''}<small class="mut">${A.esc(sub(s, it))}</small></span></button>`; });
      h += `</div>`;
    }
    h += `<div class="card"><b>${A.T('ملاحظات عامة', 'General notes')}</b><textarea rows="4" data-inp="medNotes" placeholder="${A.T('أي معلومات صحية مهمة...', 'Any important health info...')}">${A.esc(m.notes)}</textarea></div><p class="note">${A.T('بياناتك محفوظة على جهازك فقط ولا تُرفع لأي مكان.', 'Your data stays on this device only and is never uploaded.')}</p>`;
    return h;
  }
  A.chg.blood = (el) => { M().blood = el.value; A.save(); };
  A.inp.medNotes = (el) => { M().notes = el.value; A.save(); };
  function medForm(k, it) {
    const s = secOf(k), v = it || {};
    const f = s.f.map(([n, ar, en, t, req]) => {
      if (t === 'check') return `<label class="chk"><input type="checkbox" name="${n}" ${v[n] ? 'checked' : ''}> ${A.T(ar, en)}</label>`;
      if (t === 'area') return `<label>${A.T(ar, en)}<textarea name="${n}" rows="3">${A.esc(v[n] || '')}</textarea></label>`;
      return `<label>${A.T(ar, en)}<input name="${n}" type="${t}" value="${A.esc(v[n] || '')}" ${req ? 'required' : ''}></label>`;
    }).join('');
    A.modal(A.T(s.ar, s.en), `<form data-frm="medSave" data-k="${k}" data-id="${v.id || ''}" class="form">${f}<div class="row gap">${it ? `<button class="btn danger grow" type="button" data-act="medDel" data-k="${k}" data-id="${it.id}">${A.ic('trash')}</button>` : ''}<button class="btn grow" type="submit">${A.T('حفظ', 'Save')}</button></div></form>`);
  }
  A.act.medAdd = (el) => medForm(el.dataset.k, null);
  A.act.medEdit = (el) => medForm(el.dataset.k, M()[el.dataset.k].find((x) => x.id === el.dataset.id));
  A.frm.medSave = (f, fd) => {
    const k = f.dataset.k, s = secOf(k), arr = M()[k];
    const o = { id: f.dataset.id || A.uid() };
    s.f.forEach(([n, , , t]) => { o[n] = t === 'check' ? fd.get(n) === 'on' : String(fd.get(n) || '').trim(); });
    const i = arr.findIndex((x) => x.id === o.id); if (i >= 0) arr[i] = o; else arr.push(o);
    A.save(); A.closeModal(); if (k === 'meds') A.scheduleMeds();
  };
  A.act.medDel = (el) => A.confirm(A.T('حذف العنصر؟', 'Delete this item?'), () => { M()[el.dataset.k] = M()[el.dataset.k].filter((x) => x.id !== el.dataset.id); A.save(); A.closeModal(); if (el.dataset.k === 'meds') A.scheduleMeds(); });

  function summaryText() {
    const m = M(), p = A.S.profile, L = [];
    L.push(A.T('ملخص صحي — ', 'Health summary — ') + A.dkey());
    L.push(`${A.T('العمر', 'Age')}: ${p.age} | ${A.T('الطول', 'Height')}: ${p.height} cm | ${A.T('الوزن', 'Weight')}: ${A.fmt(A.lastWeight(), 1)} kg | ${A.T('فصيلة الدم', 'Blood')}: ${m.blood || '—'}`);
    const lb = H().bp[H().bp.length - 1], lg = H().glu[H().glu.length - 1];
    if (lb) L.push(`${A.T('آخر ضغط', 'Last BP')}: ${lb.sys}/${lb.dia} (${lb.d})`);
    if (lg) L.push(`${A.T('آخر سكر', 'Last glucose')}: ${lg.v} mg/dL — ${A.T(GCTX[lg.ctx][0], GCTX[lg.ctx][1])} (${lg.d})`);
    for (const s of SECS) {
      if (!m[s.k].length) continue;
      L.push('', '## ' + A.T(s.ar, s.en));
      m[s.k].forEach((it) => L.push('- ' + title(s, it) + (sub(s, it) ? ' — ' + sub(s, it) : '') + (s.k === 'meds' && it.times ? ' [' + it.times + ']' : '')));
    }
    if (m.notes) L.push('', '## ' + A.T('ملاحظات', 'Notes'), m.notes);
    return L.join('\n');
  }
  A.summaryText = summaryText;
  A.copyText = (txt) => {
    const done = () => A.toast(A.T('تم النسخ', 'Copied'));
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(txt).then(done, () => fallback()); return; } } catch (e) { /* fall */ }
    fallback();
    function fallback() {
      const t = document.createElement('textarea'); t.value = txt; document.body.appendChild(t); t.select();
      try { document.execCommand('copy'); done(); } catch (e) { A.toast('Copy failed'); } t.remove();
    }
  };
  A.act.medCopy = () => A.copyText(summaryText());
  A.act.medPrint = () => {
    const pa = document.getElementById('printArea');
    pa.innerHTML = `<pre>${A.esc(summaryText())}</pre>`;
    document.body.classList.add('printing');
    try { window.print(); } catch (e) { A.copyText(summaryText()); }
    setTimeout(() => document.body.classList.remove('printing'), 800);
  };

  /* ---------- medication reminders ---------- */
  const parseTimes = (s) => String(s || '').split(/[,،\s]+/).map((x) => x.match(/^(\d{1,2}):(\d{2})$/)).filter(Boolean).map((m) => [+m[1], +m[2]]).filter(([h, mi]) => h < 24 && mi < 60);
  A.scheduleMeds = async () => {
    const LN = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications;
    if (!LN) return;
    try {
      const perm = await LN.requestPermissions(); if (perm.display === 'denied') return;
      const pend = await LN.getPending();
      if (pend.notifications && pend.notifications.length) await LN.cancel({ notifications: pend.notifications.map((n) => ({ id: n.id })) });
      const list = []; let id = 1000;
      M().meds.forEach((m) => { if (!m.remind) return; parseTimes(m.times).forEach(([h, mi]) => list.push({ id: id++, title: A.T('موعد الدواء 💊', 'Medication time 💊'), body: m.name + (m.dose ? ' — ' + m.dose : ''), schedule: { on: { hour: h, minute: mi }, allowWhileIdle: true } })); });
      if (list.length) await LN.schedule({ notifications: list });
    } catch (e) { /* ignore */ }
  };
  let lastMin = '';
  setInterval(() => {
    const now = A.nowTime(); if (now === lastMin) return; lastMin = now;
    M().meds.forEach((m) => { if (m.remind && parseTimes(m.times).some(([h, mi]) => String(h).padStart(2, '0') + ':' + String(mi).padStart(2, '0') === now)) { A.toast('💊 ' + m.name + (m.dose ? ' — ' + m.dose : '')); A.beep(); } });
  }, 20000);
})();
