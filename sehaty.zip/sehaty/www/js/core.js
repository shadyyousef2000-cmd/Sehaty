/* Core: state, helpers, calculations, modal, charts, events */
(function () {
  'use strict';
  const KEY = 'sehaty_v1';
  const A = (window.App = { views: {}, act: {}, chg: {}, inp: {}, frm: {} });
  A.ui = { tab: 'today', date: null, wtab: 'today', htab: 'meas', mtab: 'menu', lib: { g: 'chest', q: '' } };

  /* ---------- utils ---------- */
  A.esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  A.uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3);
  A.num = (v, d = 0) => { const n = parseFloat(String(v).replace(',', '.')); return isNaN(n) ? d : n; };
  A.r = (x, d = 0) => { const m = Math.pow(10, d); return Math.round((x + Number.EPSILON) * m) / m; };
  A.fmt = (x, d = 0) => { const v = A.r(x, d); return v.toLocaleString('en-US', { maximumFractionDigits: d }); };
  A.n = (s) => '<span class="n">' + s + '</span>';
  A.clamp = (x, a, b) => Math.min(b, Math.max(a, x));

  function isObj(o) { return o && typeof o === 'object' && !Array.isArray(o); }
  function merge(base, src) {
    if (!isObj(base) || !isObj(src)) return src === undefined ? base : src;
    const out = Object.assign({}, base);
    for (const k of Object.keys(src)) out[k] = isObj(base[k]) && isObj(src[k]) ? merge(base[k], src[k]) : src[k];
    return out;
  }
  A.merge = merge;

  /* ---------- state ---------- */
  A.defaults = () => ({
    v: 1, onboarded: false,
    settings: { lang: 'ar', theme: 'auto', rest: 90, addEx: true, sound: true },
    profile: { sex: 'm', age: 25, height: 170, weight: 75, goalWeight: 70, activity: 1.375, goal: 'lose', rate: 0.5 },
    goals: { kcal: 2000, p: 140, c: 220, f: 60, water: 8, activeMin: 150 },
    diary: {}, foods: { custom: [], fav: [], recent: [] },
    workouts: { plan: null, sessions: [], current: null },
    health: { weight: [], bp: [], glu: [], body: [], sleep: [] },
    medical: { blood: '', conditions: [], meds: [], allergies: [], surgeries: [], family: [], labs: [], visits: [], notes: '' },
    fasting: { start: null, hours: 16, history: [] }
  });
  A.load = () => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return merge(A.defaults(), JSON.parse(raw));
    } catch (e) { /* ignore */ }
    return A.defaults();
  };
  A.S = A.load();
  let saveT = null;
  A.saveNow = () => { try { localStorage.setItem(KEY, JSON.stringify(A.S)); } catch (e) { A.toast(A.T('تعذّر الحفظ', 'Could not save')); } };
  A.save = () => { clearTimeout(saveT); saveT = setTimeout(A.saveNow, 120); };
  window.addEventListener('pagehide', () => A.saveNow());
  document.addEventListener('visibilitychange', () => { if (document.hidden) A.saveNow(); });

  /* ---------- language ---------- */
  A.lang = () => A.S.settings.lang;
  A.T = (ar, en) => (A.S.settings.lang === 'ar' ? ar : en);
  A.nm = (o) => (A.S.settings.lang === 'ar' ? o.ar : o.en || o.ar);
  A.un = (o) => (A.S.settings.lang === 'ar' ? o.uAr : o.uEn || o.uAr);
  A.loc = () => (A.S.settings.lang === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB');

  /* ---------- dates ---------- */
  A.dkey = (d) => {
    d = d || new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  };
  A.pk = (k) => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
  A.addDays = (k, n) => { const d = A.pk(k); d.setDate(d.getDate() + n); return A.dkey(d); };
  A.today = () => A.dkey();
  A.dlabel = (k) => {
    const t = A.today();
    if (k === t) return A.T('اليوم', 'Today');
    if (k === A.addDays(t, -1)) return A.T('أمس', 'Yesterday');
    if (k === A.addDays(t, 1)) return A.T('غدًا', 'Tomorrow');
    try { return A.pk(k).toLocaleDateString(A.loc(), { weekday: 'long', day: 'numeric', month: 'short' }); } catch (e) { return k; }
  };
  A.dshort = (k) => { try { return A.pk(k).toLocaleDateString(A.loc(), { day: 'numeric', month: 'short' }); } catch (e) { return k; } };
  A.nowTime = () => { const d = new Date(); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); };
  A.ui.date = A.today();

  /* ---------- icons ---------- */
  const IC = {
    cal: '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    dumb: '<path d="M6.5 6.5v11M17.5 6.5v11M3.5 9v6M20.5 9v6M6.5 12h11"/>',
    act: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
    heart: '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
    grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
    plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
    minus: '<line x1="5" y1="12" x2="19" y2="12"/>',
    x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
    left: '<polyline points="15 18 9 12 15 6"/>',
    right: '<polyline points="9 18 15 12 9 6"/>',
    trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
    star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
    check: '<polyline points="20 6 9 17 4 12"/>',
    more: '<circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/>',
    drop: '<path d="M12 2.7s7 7.1 7 12.3a7 7 0 0 1-14 0C5 9.8 12 2.7 12 2.7z"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/>',
    search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
    user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    play: '<polygon points="5 3 19 12 5 21 5 3"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>',
    flame: '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.07-2.14-.22-4.05 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.15.43-2.29 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>'
  };
  A.ic = (n, cls) => `<svg class="ic ${cls || ''}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n] || ''}</svg>`;

  /* ---------- toast & modal ---------- */
  let toastT = null;
  A.toast = (msg) => {
    const t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 1900);
  };
  A.modal = (title, html, opts) => {
    const r = document.getElementById('modal');
    r.innerHTML = `<div class="sheet" role="dialog" aria-modal="true"><div class="sheet-h"><b>${A.esc(title)}</b><button class="ib" data-act="closeModal" aria-label="close">${A.ic('x')}</button></div><div class="sheet-b" id="modalBody">${html}</div></div>`;
    r.classList.add('open'); document.body.classList.add('noscroll');
    A.modalOpts = opts || {};
  };
  A.setModalBody = (html) => { const b = document.getElementById('modalBody'); if (b) b.innerHTML = html; };
  A.closeModal = () => {
    const r = document.getElementById('modal');
    if (!r) return;
    r.classList.remove('open'); r.innerHTML = ''; document.body.classList.remove('noscroll');
    const cb = A.modalOpts && A.modalOpts.onClose; A.modalOpts = {};
    if (cb) cb();
    A.render();
  };
  A.confirm = (msg, yes) => {
    const el = document.getElementById('confirm');
    el.innerHTML = `<div class="cbox"><p>${A.esc(msg)}</p><div class="row gap"><button class="btn ghost grow" data-act="confirmNo">${A.T('إلغاء', 'Cancel')}</button><button class="btn danger grow" data-act="confirmYes">${A.T('تأكيد', 'Confirm')}</button></div></div>`;
    el.classList.add('open'); A._cf = yes;
  };
  A.act.confirmNo = () => { document.getElementById('confirm').classList.remove('open'); A._cf = null; };
  A.act.confirmYes = () => { const f = A._cf; A.act.confirmNo(); if (f) f(); };
  A.act.closeModal = () => A.closeModal();

  /* ---------- foods search ---------- */
  A.norm = (s) => String(s || '').toLowerCase().replace(/[ً-ٰٟ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').trim();
  A.allFoods = () => window.DATA.foods.concat(A.S.foods.custom);
  A.foodById = (id) => A.allFoods().find((x) => x.id === id);

  /* ---------- diary data ---------- */
  A.MEALS = [['b', 'الفطار', 'Breakfast'], ['l', 'الغداء', 'Lunch'], ['d', 'العشاء', 'Dinner'], ['s', 'سناكس', 'Snacks']];
  const EMPTY = Object.freeze({ m: Object.freeze({ b: [], l: [], d: [], s: [] }), w: 0, a: [] });
  A.dayR = (k) => A.S.diary[k] || EMPTY;
  A.dayW = (k) => {
    if (!A.S.diary[k]) A.S.diary[k] = { m: { b: [], l: [], d: [], s: [] }, w: 0, a: [] };
    const d = A.S.diary[k];
    if (!d.m) d.m = { b: [], l: [], d: [], s: [] };
    ['b', 'l', 'd', 's'].forEach((x) => { if (!d.m[x]) d.m[x] = []; });
    if (!d.a) d.a = [];
    return d;
  };
  A.mealTotals = (items) => items.reduce((t, i) => { t.k += i.k * i.q; t.p += i.p * i.q; t.c += i.c * i.q; t.f += i.f * i.q; return t; }, { k: 0, p: 0, c: 0, f: 0 });
  A.totals = (k) => {
    const d = A.dayR(k); const t = { k: 0, p: 0, c: 0, f: 0 };
    for (const m of ['b', 'l', 'd', 's']) { const x = A.mealTotals(d.m[m] || []); t.k += x.k; t.p += x.p; t.c += x.c; t.f += x.f; }
    return t;
  };
  A.hasFood = (k) => { const d = A.S.diary[k]; return !!d && ['b', 'l', 'd', 's'].some((m) => d.m && d.m[m] && d.m[m].length); };
  A.actBurn = (k) => A.dayR(k).a.reduce((s, x) => s + (x.kcal || 0), 0);
  A.sessBurn = (k) => A.S.workouts.sessions.filter((s) => s.date === k).reduce((s, x) => s + (x.kcal || 0), 0);
  A.burn = (k) => A.actBurn(k) + A.sessBurn(k);
  A.activeMin = (k) => A.dayR(k).a.reduce((s, x) => s + (x.min || 0), 0) + A.S.workouts.sessions.filter((s) => s.date === k).reduce((s, x) => s + (x.min || 0), 0);
  A.streak = () => {
    let k = A.today(); if (!A.hasFood(k)) k = A.addDays(k, -1);
    let n = 0; while (A.hasFood(k)) { n++; k = A.addDays(k, -1); }
    return n;
  };

  /* ---------- body calcs ---------- */
  A.bmr = (p) => { p = p || A.S.profile; return 10 * p.weight + 6.25 * p.height - 5 * p.age + (p.sex === 'm' ? 5 : -161); };
  A.tdee = (p) => { p = p || A.S.profile; return A.bmr(p) * p.activity; };
  A.bmi = (w, h) => w / Math.pow(h / 100, 2);
  A.bmiClass = (b) => b < 18.5 ? [A.T('نحافة', 'Underweight'), 'warn'] : b < 25 ? [A.T('وزن طبيعي', 'Normal'), 'ok'] : b < 30 ? [A.T('وزن زائد', 'Overweight'), 'warn'] : [A.T('سمنة', 'Obese'), 'bad'];
  A.autoGoals = (p) => {
    p = p || A.S.profile;
    const delta = p.goal === 'lose' ? -p.rate * 1100 : p.goal === 'gain' ? p.rate * 1100 : 0;
    const floor = p.sex === 'm' ? 1500 : 1200;
    const kcal = Math.max(floor, Math.round((A.tdee(p) + delta) / 10) * 10);
    let prot = Math.round(p.weight * 1.8);
    prot = Math.min(prot, Math.round(kcal * 0.35 / 4));
    const fat = Math.round(kcal * 0.27 / 9);
    const carb = Math.max(0, Math.round((kcal - prot * 4 - fat * 9) / 4));
    return { kcal, p: prot, c: carb, f: fat };
  };
  A.lastWeight = () => { const w = A.S.health.weight; return w.length ? w[w.length - 1].v : A.S.profile.weight; };

  /* ---------- activity / MET ---------- */
  A.ACTS = [
    { id: 'walk', ar: 'مشي', en: 'Walking', dist: 1, tbl: 'walk', def: 5 },
    { id: 'run', ar: 'جري', en: 'Running', dist: 1, tbl: 'run', def: 9 },
    { id: 'cycle', ar: 'دراجة', en: 'Cycling', dist: 1, tbl: 'cyc', def: 18 },
    { id: 'swim', ar: 'سباحة', en: 'Swimming', met: 6 },
    { id: 'rope', ar: 'نط الحبل', en: 'Jump rope', met: 11.8 },
    { id: 'ellip', ar: 'إليبتيكال', en: 'Elliptical', met: 5 },
    { id: 'row', ar: 'ماكينة تجديف', en: 'Rowing machine', met: 7 },
    { id: 'hiit', ar: 'HIIT (شدة عالية)', en: 'HIIT', met: 8 },
    { id: 'aerobics', ar: 'أيروبكس', en: 'Aerobics', met: 7.3 },
    { id: 'stairs', ar: 'صعود سلالم', en: 'Stair climbing', met: 8 },
    { id: 'football', ar: 'كرة قدم', en: 'Football', met: 7 },
    { id: 'basket', ar: 'كرة سلة', en: 'Basketball', met: 6.5 },
    { id: 'tennis', ar: 'تنس', en: 'Tennis', met: 7.3 },
    { id: 'squash', ar: 'اسكواش', en: 'Squash', met: 12 },
    { id: 'box', ar: 'ملاكمة / كيك بوكسينج', en: 'Boxing / Kickboxing', met: 7.8 },
    { id: 'dance', ar: 'رقص / زومبا', en: 'Dance / Zumba', met: 5.5 },
    { id: 'yoga', ar: 'يوجا', en: 'Yoga', met: 2.8 },
    { id: 'pilates', ar: 'بيلاتس', en: 'Pilates', met: 3 },
    { id: 'stretch', ar: 'إطالة', en: 'Stretching', met: 2.3 },
    { id: 'house', ar: 'شغل البيت', en: 'Housework', met: 3.3 },
    { id: 'weights', ar: 'حديد (سريع)', en: 'Weights (quick log)', met: 4.5 },
    { id: 'other', ar: 'نشاط آخر', en: 'Other activity', met: 4 }
  ];
  const TBL = {
    walk: [[3.2, 2.8], [4.0, 3.0], [4.8, 3.5], [5.6, 4.3], [6.4, 5.0], [7.2, 6.3], [8.0, 8.3]],
    run: [[4.8, 3.5], [6.4, 6.0], [8.0, 8.3], [8.4, 9.0], [9.7, 9.8], [10.8, 10.5], [11.3, 11.0], [12.1, 11.8], [12.9, 12.3], [13.8, 12.8], [14.5, 14.5], [16.1, 16.0]],
    cyc: [[10, 4.0], [16, 6.0], [19, 8.0], [22, 10.0], [25, 12.0], [30, 15.8]]
  };
  function interp(tbl, v) {
    if (v <= tbl[0][0]) return tbl[0][1];
    if (v >= tbl[tbl.length - 1][0]) return tbl[tbl.length - 1][1];
    for (let i = 1; i < tbl.length; i++) {
      if (v <= tbl[i][0]) { const [x0, y0] = tbl[i - 1], [x1, y1] = tbl[i]; return y0 + (y1 - y0) * (v - x0) / (x1 - x0); }
    }
    return tbl[tbl.length - 1][1];
  }
  A.stride = () => A.S.profile.height * 0.414 / 100; // meters
  A.calcAct = (id, min, km, steps) => {
    const a = A.ACTS.find((x) => x.id === id) || A.ACTS[A.ACTS.length - 1];
    const w = A.lastWeight();
    let speed = 0, met = a.met || 4;
    if (a.dist) {
      if (!km && steps && id === 'walk') km = steps * A.stride() / 1000;
      if (!min && km) min = (km / a.def) * 60;
      if (min && km) speed = km / (min / 60);
      else speed = a.def;
      met = interp(TBL[a.tbl], speed);
      if (!km && min) km = speed * min / 60;
    }
    const kcal = met * w * ((min || 0) / 60);
    const st = id === 'walk' ? (steps || (km ? Math.round(km * 1000 / A.stride()) : 0)) : 0;
    return { kcal: Math.round(kcal), met: A.r(met, 1), speed: A.r(speed, 1), km: A.r(km || 0, 2), min: Math.round(min || 0), steps: st };
  };

  /* ---------- charts ---------- */
  A.line = (pts, o) => {
    o = o || {};
    if (!pts.length) return `<div class="empty">${A.T('لا توجد بيانات بعد', 'No data yet')}</div>`;
    const W = 320, H = o.h || 150, pl = 36, pr = 10, pt = 14, pb = 22;
    const ys = pts.map((p) => p.y); if (o.goal != null) ys.push(o.goal);
    let mn = Math.min(...ys), mx = Math.max(...ys);
    if (mn === mx) { mn -= 1; mx += 1; }
    const pad = (mx - mn) * 0.15; mn -= pad; mx += pad;
    const ts = pts.map((p) => p.t), t0 = Math.min(...ts), t1 = Math.max(...ts);
    const X = (t) => (t1 === t0 ? pl + (W - pl - pr) / 2 : pl + (t - t0) / (t1 - t0) * (W - pl - pr));
    const Y = (y) => pt + (1 - (y - mn) / (mx - mn)) * (H - pt - pb);
    const col = o.color || 'var(--acc)';
    let g = '';
    for (let i = 0; i < 3; i++) {
      const v = mn + (mx - mn) * (i / 2), y = Y(v);
      g += `<line x1="${pl}" x2="${W - pr}" y1="${y}" y2="${y}" class="grid"/><text x="${pl - 5}" y="${y + 3}" class="axl" text-anchor="end">${A.fmt(v, o.dec || 0)}</text>`;
    }
    if (o.goal != null) g += `<line x1="${pl}" x2="${W - pr}" y1="${Y(o.goal)}" y2="${Y(o.goal)}" class="goal"/>`;
    const path = pts.map((p, i) => (i ? 'L' : 'M') + X(p.t).toFixed(1) + ' ' + Y(p.y).toFixed(1)).join(' ');
    const dots = pts.map((p) => `<circle cx="${X(p.t).toFixed(1)}" cy="${Y(p.y).toFixed(1)}" r="3" fill="${col}"/>`).join('');
    const last = pts[pts.length - 1];
    const lab = `<text x="${X(last.t)}" y="${Y(last.y) - 7}" class="vl" text-anchor="${X(last.t) > W - 40 ? 'end' : 'middle'}">${A.fmt(last.y, o.dec || 0)}</text>`;
    const first = pts[0];
    const xl = `<text x="${pl}" y="${H - 5}" class="axl">${A.dshort(A.dkey(new Date(first.t)))}</text>` + (pts.length > 1 ? `<text x="${W - pr}" y="${H - 5}" class="axl" text-anchor="end">${A.dshort(A.dkey(new Date(last.t)))}</text>` : '');
    return `<svg viewBox="0 0 ${W} ${H}" class="chart" direction="ltr" role="img">${g}<path d="${path}" fill="none" stroke="${col}" stroke-width="2.2" stroke-linejoin="round"/>${dots}${lab}${xl}</svg>`;
  };
  A.bars = (items, o) => {
    o = o || {};
    const W = 320, H = o.h || 130, pb = 20, pt = 14;
    const mx = Math.max(1, ...items.map((i) => i.v), o.goal || 0) * 1.1;
    const bw = (W - 10) / items.length;
    let s = '';
    items.forEach((it, i) => {
      const h = (it.v / mx) * (H - pb - pt), x = 5 + i * bw + bw * 0.16, w = bw * 0.68;
      const over = o.goal && it.v > o.goal;
      s += `<rect x="${x.toFixed(1)}" y="${(H - pb - h).toFixed(1)}" width="${w.toFixed(1)}" height="${Math.max(h, it.v ? 2 : 0).toFixed(1)}" rx="4" fill="${over ? 'var(--bad)' : (o.color || 'var(--acc)')}" opacity="${it.cur ? 1 : 0.72}"/>`;
      if (it.v) s += `<text x="${(x + w / 2).toFixed(1)}" y="${(H - pb - h - 4).toFixed(1)}" class="vl" text-anchor="middle">${A.fmt(it.v)}</text>`;
      s += `<text x="${(x + w / 2).toFixed(1)}" y="${H - 5}" class="axl" text-anchor="middle">${A.esc(it.l)}</text>`;
    });
    if (o.goal) { const y = H - pb - (o.goal / mx) * (H - pb - pt); s += `<line x1="0" x2="${W}" y1="${y.toFixed(1)}" y2="${y.toFixed(1)}" class="goal"/>`; }
    return `<svg viewBox="0 0 ${W} ${H}" class="chart" direction="ltr" role="img">${s}</svg>`;
  };
  A.ring = (val, max, o) => {
    o = o || {};
    const size = o.size || 150, st = o.stroke || 13, r = (size - st) / 2, C = 2 * Math.PI * r;
    const pct = max > 0 ? A.clamp(val / max, 0, 1) : 0;
    const col = o.color || 'var(--acc)';
    return `<svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" class="ring"><circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="var(--track)" stroke-width="${st}"/><circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="${col}" stroke-width="${st}" stroke-linecap="round" stroke-dasharray="${C.toFixed(1)}" stroke-dashoffset="${(C * (1 - pct)).toFixed(1)}" transform="rotate(-90 ${size / 2} ${size / 2})"/></svg>`;
  };
  A.dateNav = () => `<div class="datenav"><button class="ib" data-act="dateMove" data-n="-1" aria-label="prev">${A.lang() === 'ar' ? A.ic('right') : A.ic('left')}</button><button class="dl" data-act="dateToday">${A.esc(A.dlabel(A.ui.date))}</button><button class="ib" data-act="dateMove" data-n="1" aria-label="next">${A.lang() === 'ar' ? A.ic('left') : A.ic('right')}</button></div>`;
  A.act.dateMove = (el) => { A.ui.date = A.addDays(A.ui.date, parseInt(el.dataset.n, 10)); A.render(); };
  A.act.dateToday = () => { A.ui.date = A.today(); A.render(); };

  /* ---------- rendering & events ---------- */
  A.beep = () => {
    try {
      if (A.S.settings.sound) {
        const C = window.AudioContext || window.webkitAudioContext; if (!C) return;
        const c = new C(), o = c.createOscillator(), g = c.createGain();
        o.connect(g); g.connect(c.destination); o.frequency.value = 880; g.gain.value = 0.15;
        o.start(); setTimeout(() => { o.stop(); c.close(); }, 350);
      }
      if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
    } catch (e) { /* ignore */ }
  };
  const TABS = [['today', 'cal', 'اليوم', 'Today'], ['train', 'dumb', 'تمارين', 'Train'], ['activity', 'act', 'نشاط', 'Activity'], ['health', 'heart', 'صحتي', 'Health'], ['more', 'grid', 'المزيد', 'More']];
  A.applyTheme = () => {
    const h = document.documentElement;
    h.lang = A.lang(); h.dir = A.lang() === 'ar' ? 'rtl' : 'ltr';
    const th = A.S.settings.theme; if (th === 'auto') h.removeAttribute('data-theme'); else h.setAttribute('data-theme', th);
  };
  A.render = () => {
    A.applyTheme();
    const v = document.getElementById('view'); if (!v) return;
    const top = v.scrollTop;
    const fn = A.views[A.ui.tab];
    let html = '';
    try { html = fn ? fn() : ''; } catch (e) { html = `<div class="card bad">Error: ${A.esc(e.message)}</div>`; console.error(e); }
    v.innerHTML = html;
    v.scrollTop = top;
    const nav = document.getElementById('nav');
    nav.innerHTML = TABS.map(([id, ic, ar, en]) => `<button class="tab ${A.ui.tab === id ? 'on' : ''}" data-act="tab" data-t="${id}">${A.ic(ic)}<span>${A.T(ar, en)}</span></button>`).join('');
    if (A.afterRender) A.afterRender();
  };
  A.act.tab = (el) => { A.ui.tab = el.dataset.t; document.getElementById('view').scrollTop = 0; A.render(); };

  document.addEventListener('click', (e) => {
    if (e.target.id === 'modal') { A.closeModal(); return; }
    const el = e.target.closest('[data-act]');
    if (!el) return;
    const f = A.act[el.dataset.act];
    if (f) { e.preventDefault(); f(el, e); }
  });
  document.addEventListener('change', (e) => {
    const el = e.target.closest('[data-chg]');
    if (el && A.chg[el.dataset.chg]) A.chg[el.dataset.chg](el, e);
  });
  document.addEventListener('input', (e) => {
    const el = e.target.closest('[data-inp]');
    if (el && A.inp[el.dataset.inp]) A.inp[el.dataset.inp](el, e);
  });
  document.addEventListener('submit', (e) => {
    const f = e.target.closest('[data-frm]');
    if (f) { e.preventDefault(); const fn = A.frm[f.dataset.frm]; if (fn) fn(f, new FormData(f)); }
  });

  /* ---------- service worker ---------- */
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
  }
})();
