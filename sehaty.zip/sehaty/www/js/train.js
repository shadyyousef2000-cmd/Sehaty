/* Workouts (gym) + Activity (cardio) */
(function () {
  'use strict';
  const A = window.App, D = window.DATA;
  const exMap = {}; D.exercises.forEach((e) => (exMap[e.id] = e));
  const exName = (id) => (exMap[id] ? A.nm(exMap[id]) : id);
  const DAYS_AR = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const DAYS_EN = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayName = (i) => A.T(DAYS_AR[i], DAYS_EN[i]);
  const ORDER = [6, 0, 1, 2, 3, 4, 5];
  const W = () => A.S.workouts;
  const e1 = (kg, reps) => (kg > 0 && reps > 0 ? kg * (1 + Math.min(reps, 20) / 30) : 0);

  A.lastSets = (id) => {
    const ss = W().sessions;
    for (let i = ss.length - 1; i >= 0; i--) { const en = ss[i].entries.find((x) => x.ex === id); if (en && en.sets.length) return en.sets; }
    return null;
  };
  const fmtSets = (sets) => sets.map((s) => A.n((A.num(s.kg) ? A.fmt(A.num(s.kg), 1) + '×' : '') + A.num(s.reps))).join(' · ');

  /* ================= TRAIN ================= */
  A.views.train = () => {
    if (W().current) return sessionView();
    const tabs = [['today', A.T('اليوم', 'Today')], ['plan', A.T('الخطة', 'Plan')], ['lib', A.T('المكتبة', 'Library')], ['hist', A.T('السجل', 'History')]];
    let h = `<div class="top"><h1>${A.T('التمارين', 'Workouts')}</h1></div><div class="seg">${tabs.map(([id, l]) => `<button class="${A.ui.wtab === id ? 'on' : ''}" data-act="wtab" data-t="${id}">${l}</button>`).join('')}</div>`;
    if (A.ui.wtab === 'today') h += todayTrain();
    else if (A.ui.wtab === 'plan') h += planView();
    else if (A.ui.wtab === 'lib') h += libView();
    else h += histView();
    return h + '<div class="pad"></div>';
  };
  A.act.wtab = (el) => { A.ui.wtab = el.dataset.t; A.render(); };

  function weekStats() {
    const now = A.today(), d = A.pk(now), diff = (d.getDay() + 1) % 7; // week starts Saturday
    const start = A.addDays(now, -diff);
    const ss = W().sessions.filter((s) => s.date >= start);
    const vol = ss.reduce((t, s) => t + (s.vol || 0), 0);
    return { n: ss.length, vol, min: ss.reduce((t, s) => t + (s.min || 0), 0) };
  }

  function todayTrain() {
    const plan = W().plan, wd = new Date().getDay(), ws = weekStats();
    let h = `<div class="card stats3"><div><b>${ws.n}</b><small>${A.T('تمارين هذا الأسبوع', 'sessions this week')}</small></div><div><b>${A.fmt(ws.vol / 1000, 1)}</b><small>${A.T('طن حجم', 'tons volume')}</small></div><div><b>${A.fmt(ws.min)}</b><small>${A.T('دقيقة', 'minutes')}</small></div></div>`;
    if (!plan) {
      h += `<div class="card"><h3>${A.T('لسه ما اخترتش خطة', 'No plan yet')}</h3><p class="mut">${A.T('اختار خطة جاهزة أو ابدأ تمرين فاضي وسجّل اللي بتعمله.', 'Pick a ready plan, or start an empty session and log what you do.')}</p><div class="row gap"><button class="btn grow" data-act="wtab" data-t="plan">${A.T('اختيار خطة', 'Choose plan')}</button><button class="btn ghost grow" data-act="startEmpty">${A.T('تمرين فاضي', 'Empty session')}</button></div></div>`;
      return h;
    }
    const day = plan.days[wd] || { name: '', ex: [] };
    if (!day.ex.length) {
      h += `<div class="card"><h3>${A.T('النهارده راحة', 'Rest day today')} 😴</h3><p class="mut">${A.esc(dayName(wd))} — ${A.esc(day.name || A.T('راحة', 'Rest'))}</p><button class="btn ghost full" data-act="startEmpty">${A.T('عايز أتمرن برضه — جلسة فاضية', 'Train anyway — empty session')}</button></div>`;
    } else {
      h += `<div class="card"><div class="mh"><div><small class="mut">${A.esc(dayName(wd))}</small><h3>${A.esc(day.name)}</h3></div></div>`;
      for (const [id, s, r] of day.ex) {
        const ls = A.lastSets(id);
        h += `<div class="item static"><span class="in">${A.esc(exName(id))}<small class="mut">${ls ? A.T('آخر مرة: ', 'Last: ') + fmtSets(ls.slice(0, 4)) : ''}</small></span><span class="ik sm">${A.n(s + '×' + r)}</span></div>`;
      }
      h += `<button class="btn full" data-act="startPlan">${A.ic('play')} ${A.T('ابدأ التمرين', 'Start workout')}</button></div><button class="btn ghost full" data-act="startEmpty">${A.T('جلسة فاضية', 'Empty session')}</button>`;
    }
    return h;
  }

  /* ---------- plan ---------- */
  function planView() {
    const plan = W().plan;
    let h = '';
    if (plan) {
      h += `<div class="card"><div class="mh"><div><small class="mut">${A.T('خطتك الحالية', 'Current plan')}</small><h3>${A.esc(plan.name)}</h3></div></div>`;
      for (const d of ORDER) {
        const day = plan.days[d] || { name: '', ex: [] };
        h += `<button class="item" data-act="editDay" data-d="${d}"><span class="in">${A.esc(dayName(d))}<small class="mut">${A.esc(day.name || '')}</small></span><span class="ik sm">${day.ex.length ? day.ex.length + ' ' + A.T('تمارين', 'exercises') : A.T('راحة', 'Rest')}</span></button>`;
      }
      h += `</div><h3>${A.T('تغيير الخطة', 'Switch plan')}</h3>`;
    } else h += `<h3>${A.T('اختر خطة', 'Choose a plan')}</h3>`;
    h += D.templates.map((t) => `<button class="card link tpl" data-act="useTpl" data-id="${t.id}"><b>${A.esc(A.nm(t))}</b><small class="mut">${Object.values(t.days).filter((d) => d.ex.length).length} ${A.T('أيام تمرين', 'training days')}</small></button>`).join('');
    h += `<button class="card link tpl" data-act="useTpl" data-id="blank"><b>${A.T('خطة فاضية (أصممها بنفسي)', 'Blank plan (build my own)')}</b></button>`;
    return h;
  }
  A.act.useTpl = (el) => {
    const go = () => {
      const t = D.templates.find((x) => x.id === el.dataset.id), days = {};
      for (let d = 0; d < 7; d++) {
        const src = t && t.days[d];
        days[d] = src ? { name: A.nm(src), ex: src.ex.map((x) => x.slice()) } : { name: A.T('راحة', 'Rest'), ex: [] };
      }
      W().plan = { id: A.uid(), name: t ? A.nm(t) : A.T('خطتي', 'My plan'), days };
      A.save(); A.render(); A.toast(A.T('تم تفعيل الخطة', 'Plan activated'));
    };
    if (W().plan) A.confirm(A.T('استبدال الخطة الحالية؟', 'Replace the current plan?'), go); else go();
  };
  let pd = null;
  A.act.editDay = (el) => { pd = parseInt(el.dataset.d, 10); dayEditor(true); };
  function dayEditor(open) {
    const day = W().plan.days[pd];
    let b = `<label class="lbl">${A.T('اسم اليوم', 'Day name')}<input value="${A.esc(day.name)}" data-inp="pdName"></label>`;
    day.ex.forEach((x, i) => {
      b += `<div class="erow"><span class="in">${A.esc(exName(x[0]))}</span><input class="sm" type="number" inputmode="numeric" value="${x[1]}" data-inp="pdSets" data-i="${i}" aria-label="sets"><span>×</span><input class="sm" type="number" inputmode="numeric" value="${x[2]}" data-inp="pdReps" data-i="${i}" aria-label="reps"><button class="ib" data-act="pdDel" data-i="${i}">${A.ic('trash')}</button></div>`;
    });
    if (!day.ex.length) b += `<div class="empty">${A.T('يوم راحة — أضف تمارين لو عايز', 'Rest day — add exercises if you like')}</div>`;
    b += `<button class="btn full" data-act="pdAdd">${A.ic('plus')} ${A.T('إضافة تمرين', 'Add exercise')}</button>`;
    const t = dayName(pd);
    if (open) A.modal(t, b); else A.setModalBody(b);
  }
  A.inp.pdName = (el) => { W().plan.days[pd].name = el.value; A.save(); };
  A.inp.pdSets = (el) => { W().plan.days[pd].ex[+el.dataset.i][1] = A.num(el.value, 3); A.save(); };
  A.inp.pdReps = (el) => { W().plan.days[pd].ex[+el.dataset.i][2] = A.num(el.value, 10); A.save(); };
  A.act.pdDel = (el) => { W().plan.days[pd].ex.splice(+el.dataset.i, 1); A.save(); dayEditor(false); };
  A.act.pdAdd = () => A.pickEx((id) => { W().plan.days[pd].ex.push([id, 3, 10]); A.save(); dayEditor(false); }, () => dayEditor(false));

  /* ---------- exercise picker ---------- */
  let pick = { g: 'chest', q: '', cb: null, back: null };
  A.pickEx = (cb, back) => { pick = { g: 'chest', q: '', cb, back }; pickRender(); };
  function pickRender() {
    const chips = `<div class="chips">${D.groups.map((g) => `<button class="chip ${pick.g === g.id ? 'on' : ''}" data-act="pickG" data-g="${g.id}">${A.esc(A.nm(g))}</button>`).join('')}</div>`;
    const b = `<div class="searchbox">${A.ic('search')}<input type="search" id="pickq" placeholder="${A.T('ابحث عن تمرين', 'Search exercise')}" value="${A.esc(pick.q)}" data-inp="pickq" autocomplete="off"></div>${chips}<div id="pickRes">${pickList()}</div>${pick.back ? `<button class="btn ghost full" data-act="pickBack">${A.T('رجوع', 'Back')}</button>` : ''}`;
    if (document.getElementById('modal').classList.contains('open')) A.setModalBody(b); else A.modal(A.T('اختر تمرين', 'Pick exercise'), b);
  }
  function pickList() {
    const q = A.norm(pick.q);
    let l = D.exercises;
    l = q ? l.filter((e) => A.norm(e.ar + ' ' + e.en).includes(q)) : l.filter((e) => e.grp === pick.g);
    if (!l.length) return `<div class="empty">${A.T('مفيش نتائج', 'No results')}</div>`;
    return l.map((e) => `<button class="item" data-act="pickDo" data-id="${e.id}"><span class="in">${A.esc(A.nm(e))}</span></button>`).join('');
  }
  A.inp.pickq = (el) => { pick.q = el.value; document.getElementById('pickRes').innerHTML = pickList(); };
  A.act.pickG = (el) => { pick.g = el.dataset.g; pick.q = ''; pickRender(); };
  A.act.pickDo = (el) => { const cb = pick.cb; if (cb) cb(el.dataset.id); };
  A.act.pickBack = () => { if (pick.back) pick.back(); };

  /* ---------- session ---------- */
  function newSets(id, n, reps) {
    const ls = A.lastSets(id), kg = ls && ls[0] ? ls[0].kg : '';
    return Array.from({ length: n }, (_, i) => ({ kg: ls && ls[i] ? ls[i].kg : kg, reps: reps || (ls && ls[i] ? ls[i].reps : ''), done: false }));
  }
  A.act.startPlan = () => {
    const day = W().plan.days[new Date().getDay()];
    W().current = { id: A.uid(), name: day.name, start: Date.now(), entries: day.ex.map(([id, s, r]) => ({ ex: id, sets: newSets(id, s, r) })) };
    A.save(); A.render();
  };
  A.act.startEmpty = () => { W().current = { id: A.uid(), name: A.T('تمرين حر', 'Free workout'), start: Date.now(), entries: [] }; A.save(); A.render(); };

  function sessionView() {
    const c = W().current;
    let h = `<div class="top"><h1>${A.T('جلسة جارية', 'Workout in progress')}</h1><span class="chip" id="sessClock">${A.ic('clock')} ${clock(c.start)}</span></div>
      <input class="titlein" value="${A.esc(c.name)}" data-inp="sessName" aria-label="name">`;
    c.entries.forEach((en, ei) => {
      const ls = A.lastSets(en.ex);
      h += `<div class="card ex"><div class="mh"><div><b>${A.esc(exName(en.ex))}</b>${ls ? `<small class="mut block">${A.T('آخر مرة: ', 'Last: ')}${fmtSets(ls.slice(0, 5))}</small>` : ''}</div><button class="ib" data-act="delEntry" data-e="${ei}" aria-label="remove">${A.ic('trash')}</button></div>
        <div class="srow head"><span>${A.T('مجموعة', 'Set')}</span><span>${A.T('كجم', 'kg')}</span><span>${A.T('عدّات', 'Reps')}</span><span></span></div>`;
      en.sets.forEach((s, si) => {
        h += `<div class="srow ${s.done ? 'done' : ''}"><span class="sn">${si + 1}</span><input type="number" inputmode="decimal" step="0.5" value="${A.esc(s.kg)}" data-inp="sf" data-e="${ei}" data-s="${si}" data-f="kg" aria-label="kg"><input type="number" inputmode="numeric" value="${A.esc(s.reps)}" data-inp="sf" data-e="${ei}" data-s="${si}" data-f="reps" aria-label="reps"><button class="ck ${s.done ? 'on' : ''}" data-act="setDone" data-e="${ei}" data-s="${si}" aria-label="done">${A.ic('check')}</button></div>`;
      });
      h += `<div class="row gap"><button class="btn ghost grow sm" data-act="addSet" data-e="${ei}">${A.ic('plus')} ${A.T('مجموعة', 'Set')}</button><button class="btn ghost grow sm" data-act="delSet" data-e="${ei}">${A.ic('minus')} ${A.T('مجموعة', 'Set')}</button></div></div>`;
    });
    h += `<button class="btn full" data-act="addEntry">${A.ic('plus')} ${A.T('إضافة تمرين', 'Add exercise')}</button>
      <div class="row gap"><button class="btn danger grow" data-act="discardSess">${A.T('إلغاء الجلسة', 'Discard')}</button><button class="btn grow" data-act="finishSess">${A.ic('check')} ${A.T('إنهاء', 'Finish')}</button></div><div class="pad rest"></div>`;
    return h;
  }
  const clock = (st) => { const s = Math.floor((Date.now() - st) / 1000), m = Math.floor(s / 60); return Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };
  A.inp.sessName = (el) => { W().current.name = el.value; A.save(); };
  A.inp.sf = (el) => { W().current.entries[+el.dataset.e].sets[+el.dataset.s][el.dataset.f] = el.value; A.save(); };
  A.act.addSet = (el) => {
    const en = W().current.entries[+el.dataset.e], l = en.sets[en.sets.length - 1] || {};
    en.sets.push({ kg: l.kg || '', reps: l.reps || '', done: false }); A.save(); A.render();
  };
  A.act.delSet = (el) => { const en = W().current.entries[+el.dataset.e]; if (en.sets.length) en.sets.pop(); A.save(); A.render(); };
  A.act.delEntry = (el) => { W().current.entries.splice(+el.dataset.e, 1); A.save(); A.render(); };
  A.act.addEntry = () => A.pickEx((id) => {
    W().current.entries.push({ ex: id, sets: newSets(id, 3, '') }); A.save(); A.closeModal();
  }, () => A.closeModal());
  A.act.setDone = (el) => {
    const s = W().current.entries[+el.dataset.e].sets[+el.dataset.s]; s.done = !s.done; A.save();
    if (s.done && A.S.settings.rest > 0) startRest(A.S.settings.rest);
    A.render();
  };
  A.act.discardSess = () => A.confirm(A.T('إلغاء الجلسة بدون حفظ؟', 'Discard this workout without saving?'), () => { W().current = null; stopRest(); A.save(); A.render(); });
  A.act.finishSess = () => {
    const c = W().current, done = c.entries.reduce((n, e) => n + e.sets.filter((s) => s.done).length, 0);
    if (!done) { A.confirm(A.T('مفيش أي مجموعة متعلّم عليها ✓. إلغاء الجلسة؟', 'No sets are checked ✓. Discard the workout?'), () => { W().current = null; A.save(); A.render(); }); return; }
    const min = Math.max(1, Math.round((Date.now() - c.start) / 60000)), kcal = Math.round(4.5 * A.lastWeight() * min / 60);
    A.modal(A.T('إنهاء التمرين', 'Finish workout'), `<form data-frm="finish" class="form"><label>${A.T('الاسم', 'Name')}<input name="n" value="${A.esc(c.name)}"></label><div class="g2"><label>${A.T('المدة (دقيقة)', 'Duration (min)')}<input name="min" type="number" value="${min}"></label><label>${A.T('سعرات محروقة (تقدير)', 'Calories burned (est.)')}<input name="kcal" type="number" value="${kcal}"></label></div><button class="btn full" type="submit">${A.T('حفظ التمرين', 'Save workout')}</button></form>`);
  };
  A.frm.finish = (f, fd) => {
    const c = W().current, prevBest = {};
    W().sessions.forEach((s) => s.entries.forEach((e) => e.sets.forEach((x) => { const v = e1(A.num(x.kg), A.num(x.reps)); if (v > (prevBest[e.ex] || 0)) prevBest[e.ex] = v; })));
    const entries = [], prs = []; let vol = 0;
    c.entries.forEach((e) => {
      const sets = e.sets.filter((s) => s.done).map((s) => ({ kg: A.num(s.kg), reps: A.num(s.reps) }));
      if (!sets.length) return;
      sets.forEach((s) => { vol += (s.kg || 1) * s.reps; });
      const best = Math.max(...sets.map((s) => e1(s.kg, s.reps)));
      if (best > 0 && best > (prevBest[e.ex] || 0) + 0.01 && prevBest[e.ex]) prs.push(exName(e.ex));
      entries.push({ ex: e.ex, sets });
    });
    W().sessions.push({ id: c.id, date: A.today(), name: String(fd.get('n') || c.name), min: A.num(fd.get('min'), 30), kcal: A.num(fd.get('kcal'), 0), vol: Math.round(vol), entries });
    W().current = null; stopRest(); A.save();
    A.setModalBody(`<div class="center"><div class="big">🎉</div><h3>${A.T('أحسنت! التمرين اتسجل', 'Great job! Workout saved')}</h3><p class="mut">${A.T('الحجم الكلي', 'Total volume')}: ${A.fmt(vol)} ${A.T('كجم', 'kg')}</p>${prs.length ? `<div class="card ok">🏆 ${A.T('أرقام قياسية جديدة', 'New personal records')}: ${prs.map(A.esc).join('، ')}</div>` : ''}<button class="btn full" data-act="closeModal">${A.T('تمام', 'Done')}</button></div>`);
  };

  /* ---------- rest timer ---------- */
  let restEnd = 0, restInt = null;
  function startRest(sec) { restEnd = Date.now() + sec * 1000; ensureInt(); restPaint(); }
  function stopRest() { restEnd = 0; restPaint(); }
  function ensureInt() { if (!restInt) restInt = setInterval(tick, 500); }
  function tick() {
    const c = document.getElementById('sessClock'); if (c && W().current) c.innerHTML = A.ic('clock') + ' ' + clock(W().current.start);
    if (restEnd && Date.now() >= restEnd) { restEnd = 0; A.beep(); A.toast(A.T('انتهت الراحة — كمّل! 💪', 'Rest over — go! 💪')); }
    restPaint();
    const fl = document.getElementById('fastClock'); if (fl) fl.textContent = A.fastElapsed();
  }
  function restPaint() {
    const r = document.getElementById('rest'); if (!r) return;
    if (!restEnd || !W().current) { r.classList.remove('show'); r.innerHTML = ''; return; }
    const left = Math.max(0, Math.ceil((restEnd - Date.now()) / 1000));
    if (!r.classList.contains('show')) r.classList.add('show');
    r.innerHTML = `<span>${A.T('راحة', 'Rest')} <b>${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}</b></span><span class="row"><button class="chip" data-act="restAdj" data-n="-15">-15</button><button class="chip" data-act="restAdj" data-n="15">+15</button><button class="chip" data-act="restSkip">${A.T('تخطي', 'Skip')}</button></span>`;
  }
  A.act.restAdj = (el) => { restEnd = Math.max(Date.now() + 1000, restEnd + parseInt(el.dataset.n, 10) * 1000); restPaint(); };
  A.act.restSkip = () => stopRest();
  setInterval(() => { if (W().current || A.S.fasting.start) { ensureInt(); } }, 3000);
  A.afterRender = () => { if (W().current || A.S.fasting.start) ensureInt(); restPaint(); };

  /* ---------- library & history ---------- */
  function libView() {
    const L = A.ui.lib, q = A.norm(L.q);
    let l = D.exercises; l = q ? l.filter((e) => A.norm(e.ar + ' ' + e.en).includes(q)) : l.filter((e) => e.grp === L.g);
    return `<div class="searchbox">${A.ic('search')}<input type="search" value="${A.esc(L.q)}" placeholder="${A.T('ابحث عن تمرين', 'Search exercise')}" data-inp="libq"></div><div class="chips">${D.groups.map((g) => `<button class="chip ${L.g === g.id && !q ? 'on' : ''}" data-act="libG" data-g="${g.id}">${A.esc(A.nm(g))}</button>`).join('')}</div><div id="libRes">${libList(l)}</div>`;
  }
  const libList = (l) => l.map((e) => { const ls = A.lastSets(e.id); return `<button class="item" data-act="exInfo" data-id="${e.id}"><span class="in">${A.esc(A.nm(e))}<small class="mut">${ls ? fmtSets(ls.slice(0, 3)) : ''}</small></span></button>`; }).join('') || `<div class="empty">${A.T('مفيش نتائج', 'No results')}</div>`;
  A.inp.libq = (el) => { A.ui.lib.q = el.value; const q = A.norm(el.value), L = A.ui.lib; document.getElementById('libRes').innerHTML = libList(q ? D.exercises.filter((e) => A.norm(e.ar + ' ' + e.en).includes(q)) : D.exercises.filter((e) => e.grp === L.g)); };
  A.act.libG = (el) => { A.ui.lib.g = el.dataset.g; A.ui.lib.q = ''; A.render(); };
  A.act.exInfo = (el) => {
    const id = el.dataset.id, pts = [], rows = [];
    W().sessions.forEach((s) => s.entries.forEach((e) => {
      if (e.ex !== id) return;
      const best = Math.max(0, ...e.sets.map((x) => e1(x.kg, x.reps)));
      if (best) pts.push({ t: A.pk(s.date).getTime(), y: best });
      rows.push({ d: s.date, s: e.sets });
    }));
    const pr = pts.length ? Math.max(...pts.map((p) => p.y)) : 0;
    A.modal(exName(id), `<p class="mut">${A.T('أفضل 1RM تقديري', 'Best estimated 1RM')}: <b>${pr ? A.fmt(pr, 1) + ' ' + A.T('كجم', 'kg') : '—'}</b></p>${A.line(pts, { dec: 0 })}<h3>${A.T('آخر المرات', 'Recent')}</h3>${rows.slice(-6).reverse().map((r) => `<div class="item static"><span class="in">${A.esc(A.dshort(r.d))}<small class="mut">${fmtSets(r.s)}</small></span></div>`).join('') || `<div class="empty">${A.T('لا يوجد سجل', 'No history')}</div>`}`);
  };
  function histView() {
    const ss = W().sessions.slice().reverse();
    if (!ss.length) return `<div class="empty">${A.T('لسه ما سجلتش تمارين', 'No workouts logged yet')}</div>`;
    return ss.map((s) => `<button class="card link tpl" data-act="sessInfo" data-id="${s.id}"><div class="mh"><b>${A.esc(s.name)}</b><small class="mut">${A.esc(A.dshort(s.date))}</small></div><small class="mut">${s.entries.length} ${A.T('تمارين', 'exercises')} · ${s.min} ${A.T('د', 'min')} · ${A.fmt(s.vol)} ${A.T('كجم حجم', 'kg vol')} · ${A.fmt(s.kcal)} ${A.T('سعرة', 'kcal')}</small></button>`).join('');
  }
  A.act.sessInfo = (el) => {
    const s = W().sessions.find((x) => x.id === el.dataset.id); if (!s) return;
    A.modal(s.name, `<p class="mut">${A.esc(A.dlabel(s.date))} · ${s.min} ${A.T('دقيقة', 'min')} · ${A.fmt(s.kcal)} ${A.T('سعرة', 'kcal')}</p>${s.entries.map((e) => `<div class="item static"><span class="in"><b>${A.esc(exName(e.ex))}</b><small class="mut">${fmtSets(e.sets)}</small></span></div>`).join('')}<button class="btn danger full" data-act="delSess" data-id="${s.id}">${A.ic('trash')} ${A.T('حذف الجلسة', 'Delete session')}</button>`);
  };
  A.act.delSess = (el) => A.confirm(A.T('حذف الجلسة؟', 'Delete this session?'), () => { W().sessions = W().sessions.filter((x) => x.id !== el.dataset.id); A.save(); A.closeModal(); });

  /* ================= ACTIVITY ================= */
  const F = (A.ui.actForm = { id: 'walk', min: '', km: '', steps: '', kcal: '' });
  A.views.activity = () => {
    const k = A.ui.date, d = A.dayR(k), g = A.S.goals;
    let wk = 0; for (let i = 0; i < 7; i++) wk += A.activeMin(A.addDays(A.today(), -i));
    const items = []; for (let i = 6; i >= 0; i--) { const dk = A.addDays(A.today(), -i); items.push({ l: A.pk(dk).toLocaleDateString(A.loc(), { weekday: 'narrow' }), v: A.burn(dk), cur: i === 0 }); }
    const a = A.ACTS.find((x) => x.id === F.id), calc = A.calcAct(F.id, A.num(F.min), A.num(F.km), A.num(F.steps));
    let h = `<div class="top"><h1>${A.T('النشاط', 'Activity')}</h1></div>${A.dateNav()}
      <div class="card stats3"><div><b>${A.fmt(A.burn(k))}</b><small>${A.T('سعرة محروقة', 'kcal burned')}</small></div><div><b>${A.activeMin(k)}</b><small>${A.T('دقيقة نشاط', 'active min')}</small></div><div><b>${A.n(wk + '<span class="mut sm">/' + g.activeMin + '</span>')}</b><small>${A.T('آخر 7 أيام', 'last 7 days')}</small></div></div>
      <div class="card"><b>${A.T('الحرق آخر 7 أيام', 'Burn — last 7 days')}</b>${A.bars(items, { color: 'var(--acc2)' })}</div>
      <div class="card"><h3>${A.T('سجّل نشاط', 'Log activity')}</h3><div class="form">
      <label>${A.T('النوع', 'Type')}<select data-chg="actSel">${A.ACTS.map((x) => `<option value="${x.id}" ${x.id === F.id ? 'selected' : ''}>${A.esc(A.nm(x))}</option>`).join('')}</select></label>
      <div class="g2"><label>${A.T('المدة (دقيقة)', 'Duration (min)')}<input type="number" inputmode="decimal" value="${A.esc(F.min)}" data-inp="actf" data-f="min"></label>
      ${a.dist ? `<label>${A.T('المسافة (كم)', 'Distance (km)')}<input type="number" inputmode="decimal" step="0.1" value="${A.esc(F.km)}" data-inp="actf" data-f="km"></label>` : ''}
      ${F.id === 'walk' ? `<label>${A.T('أو عدد الخطوات', 'Or steps')}<input type="number" inputmode="numeric" value="${A.esc(F.steps)}" data-inp="actf" data-f="steps"></label>` : ''}
      <label>${A.T('سعرات (لو معروفة)', 'Calories (if known)')}<input type="number" inputmode="decimal" value="${A.esc(F.kcal)}" data-inp="actf" data-f="kcal" placeholder="${A.T('تلقائي', 'auto')}"></label></div>
      <div class="prev" id="actPrev">${actPrev(calc)}</div>
      <button class="btn full" data-act="saveAct">${A.ic('plus')} ${A.T('إضافة', 'Add')}</button></div></div>`;
    const sess = W().sessions.filter((s) => s.date === k);
    h += `<h3>${A.T('سجل اليوم', 'Log')}</h3>`;
    if (!d.a.length && !sess.length) h += `<div class="empty">${A.T('لا يوجد نشاط مسجل', 'No activity logged')}</div>`;
    d.a.forEach((x) => { const t = A.ACTS.find((y) => y.id === x.type) || {}; h += `<div class="item static"><span class="in">${A.esc(A.nm(t))}<small class="mut">${x.min} ${A.T('د', 'min')}${x.km ? ' · ' + A.fmt(x.km, 2) + ' ' + A.T('كم', 'km') : ''}${x.steps ? ' · ' + A.fmt(x.steps) + ' ' + A.T('خطوة', 'steps') : ''}</small></span><span class="ik">${A.fmt(x.kcal)}</span><button class="ib" data-act="delAct" data-id="${x.id}">${A.ic('trash')}</button></div>`; });
    sess.forEach((s) => { h += `<div class="item static"><span class="in">${A.esc(s.name)}<small class="mut">${A.T('تمرين جيم', 'Gym workout')} · ${s.min} ${A.T('د', 'min')}</small></span><span class="ik">${A.fmt(s.kcal)}</span></div>`; });
    h += `<p class="note">${A.T('السعرات تقديرية بمعادلة MET (الوزن × شدة النشاط × الزمن) وبتختلف من شخص لشخص.', 'Calories are estimates using METs (weight × intensity × time) and vary between people.')}</p>`;
    return h + '<div class="pad"></div>';
  };
  const actPrev = (c) => `<div><b>${A.fmt(F.kcal ? A.num(F.kcal) : c.kcal)}</b><small>${A.T('سعرة', 'kcal')}</small></div><div><b>${c.met}</b><small>MET</small></div>${c.speed ? `<div><b>${c.speed}</b><small>${A.T('كم/س', 'km/h')}</small></div>` : ''}${c.steps ? `<div><b>${A.fmt(c.steps)}</b><small>${A.T('خطوة', 'steps')}</small></div>` : ''}`;
  A.chg.actSel = (el) => { F.id = el.value; F.km = ''; F.steps = ''; A.render(); };
  A.inp.actf = (el) => { F[el.dataset.f] = el.value; const p = document.getElementById('actPrev'); if (p) p.innerHTML = actPrev(A.calcAct(F.id, A.num(F.min), A.num(F.km), A.num(F.steps))); };
  A.act.saveAct = () => {
    const c = A.calcAct(F.id, A.num(F.min), A.num(F.km), A.num(F.steps));
    if (!c.min) { A.toast(A.T('اكتب المدة أو المسافة', 'Enter duration or distance')); return; }
    const d = A.dayW(A.ui.date);
    d.a.push({ id: A.uid(), type: F.id, min: c.min, km: c.km, steps: c.steps, kcal: F.kcal ? A.num(F.kcal) : c.kcal });
    F.min = F.km = F.steps = F.kcal = ''; A.save(); A.toast(A.T('تمت الإضافة ✓', 'Added ✓')); A.render();
  };
  A.act.delAct = (el) => { const d = A.dayW(A.ui.date); d.a = d.a.filter((x) => x.id !== el.dataset.id); A.save(); A.render(); };
})();
